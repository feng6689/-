# -*- coding: utf-8 -*-
"""Render one timeline segment straight to an H.264 mp4 part (resumable)."""
import os
import subprocess
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import stage  # noqa: E402

FPS, W, H = 30, 1920, 1080
BOUNDS = [0, 600, 1500, 2550, 3600, 4350, 5100, 5400]      # the seven beats


def render(f0, f1, out, crf=18, preset="veryfast"):
    sc = stage.Scene()
    cmd = ["ffmpeg", "-y", "-v", "error", "-f", "rawvideo", "-pix_fmt", "rgb24",
           "-s", f"{W}x{H}", "-r", str(FPS), "-i", "-", "-an",
           "-c:v", "libx264", "-preset", preset, "-crf", str(crf),
           "-pix_fmt", "yuv420p", "-profile:v", "high", "-level", "4.0",
           "-g", "60", "-keyint_min", "60", "-sc_threshold", "0",
           "-movflags", "+faststart", out]
    p = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    t0 = time.time()
    for f in range(f0, f1):
        p.stdin.write(sc.render(f / float(FPS)).tobytes())
        if (f - f0) % 150 == 0:
            el = time.time() - t0
            done = f - f0 + 1
            print(f"    f{f} {done / max(el, 0.01):.2f} fps  eta {(f1 - f) / max(done / max(el, 0.01), 0.01) / 60:.1f} min",
                  flush=True)
    p.stdin.close()
    code = p.wait()
    if code != 0:
        raise SystemExit(f"ffmpeg exited {code}")
    return out


def frames_of(path):
    r = subprocess.run(["ffprobe", "-v", "error", "-count_frames", "-select_streams", "v:0",
                        "-show_entries", "stream=nb_read_frames", "-of", "default=nw=1:nk=1",
                        path], capture_output=True, text=True)
    try:
        return int(r.stdout.strip())
    except Exception:
        return -1


if __name__ == "__main__":
    i = int(sys.argv[1])
    f0, f1 = BOUNDS[i], BOUNDS[i + 1]
    out = os.path.join(HERE, "build", "parts", f"seg{i + 1}.mp4")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    if os.path.exists(out) and frames_of(out) == (f1 - f0) and "--force" not in sys.argv:
        print(f"seg{i + 1} already complete ({f1 - f0} frames) - skip")
        sys.exit(0)
    print(f"rendering seg{i + 1}: frames {f0}..{f1 - 1}", flush=True)
    render(f0, f1, out)
    n = frames_of(out)
    print(f"seg{i + 1} done: {n} frames (expected {f1 - f0})")
    if n != (f1 - f0):
        raise SystemExit("frame count mismatch")