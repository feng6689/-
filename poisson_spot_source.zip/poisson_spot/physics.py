# -*- coding: utf-8 -*-
"""Fresnel diffraction behind a circular / irregular obstacle.

Normalisation: the unobstructed (free) field has unit amplitude, so the on-axis
intensity behind a perfectly circular disk is exactly 1 -- the Poisson spot at
full brightness (verified in self_test()).

The screen pattern is tabulated in the two dimensionless variables that the
circular-obstacle Fresnel integral depends on:
    N = a^2 / (lambda z)        (Fresnel number)
    x = r / a                   (radial coordinate / disk radius)
so one table serves every wavelength / disk size / distance used in the film.
"""
import os
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
TABLE = os.path.join(HERE, "build", "pattern_table.npz")


# --------------------------------------------------------------- Bessel J0 --
def j0(x):
    """Bessel J0(x): Taylor series for |x| <= 25, asymptotic series beyond."""
    x = np.asarray(x, dtype=np.float64)
    ax = np.abs(x)
    out = np.empty_like(ax)
    s = ax <= 25.0
    if np.any(s):
        y = (ax[s] * 0.5) ** 2
        term = np.ones_like(y)
        total = np.ones_like(y)
        for m in range(1, 80):
            term = -term * y / (m * m)
            total = total + term
            if np.max(np.abs(term)) <= 1e-17:
                break
        out[s] = total
    b = ~s
    if np.any(b):
        xx = ax[b]
        P = 1.0 - 9.0 / (128.0 * xx ** 2) + 225.0 / (24576.0 * xx ** 4)
        Q = 1.0 / (8.0 * xx) - 225.0 / (1024.0 * xx ** 3)
        ph = xx - np.pi / 4.0
        out[b] = np.sqrt(2.0 / (np.pi * xx)) * (P * np.cos(ph) - Q * np.sin(ph))
    return out


def j0_ref(x):
    """Independent reference J0 via (1/pi) int cos(x sin t) dt (slow, for tests)."""
    x = np.atleast_1d(np.asarray(x, dtype=np.float64))
    t = np.linspace(0.0, np.pi, 200001)
    st = np.sin(t)
    u = np.empty_like(x)
    for i, xi in enumerate(x):
        u[i] = np.trapezoid(np.cos(xi * st), t) / np.pi
    return u


# ------------------------------------------------------------ pattern table --
def _intensity_Nx(N, xgrid, nrho=1600):
    """I(r/a) for Fresnel number N, using the obstacle form U=1-exp(i beta r^2)A(r)."""
    a = 1.0                       # unit radius; lengths are multiples of a
    lamz = a * a / N              # lambda*z in units of a^2
    beta = np.pi / lamz
    rho = np.linspace(0.0, a, nrho)
    rho_w = rho * 1.0
    integ = np.exp(1j * beta * rho_w ** 2) * rho_w   # exp(i beta rho^2) rho
    out = np.empty(len(xgrid))
    pref = -2j * np.pi / lamz
    for i, x in enumerate(xgrid):
        arg = 2.0 * np.pi * rho_w * x / lamz
        vals = integ * j0(arg)
        J = np.trapezoid(vals, rho_w)
        A = pref * J
        out[i] = abs(1.0 - np.exp(1j * beta * ((x * a) ** 2)) * A) ** 2
    return out


def build_table(force=False, nN=72, nx=1200, nrho=2000):
    if os.path.exists(TABLE) and not force:
        d = np.load(TABLE)
        return d["N"], d["x"], d["I"]
    os.makedirs(os.path.dirname(TABLE), exist_ok=True)
    Ngrid = np.geomspace(10.0, 90.0, nN)
    x = np.concatenate([np.linspace(0.0, 0.45, 700), np.linspace(0.45, 1.5, 300),
                        np.linspace(1.5, 2.0, 120)])
    I = np.empty((nN, len(x)), dtype=np.float32)
    for k, N in enumerate(Ngrid):
        I[k] = _intensity_Nx(float(N), x, nrho=nrho)
    np.savez_compressed(TABLE, N=Ngrid, x=x, I=I)
    return Ngrid, x, I


class Pattern:
    """Interpolated radial pattern for any (lambda, a) at a given N."""

    def __init__(self, table=None):
        self.N, self.x, self.I = table if table else build_table()

    def profile(self, lam_nm, a_mm, z_m):
        """Radial intensity profile I(x) sampled on the table's x grid."""
        N = (a_mm * 1e-3) ** 2 / (lam_nm * 1e-9 * z_m)
        N = float(np.clip(N, self.N[0], self.N[-1]))
        k = np.interp(np.log(N), np.log(self.N), np.arange(len(self.N)))
        k0, k1 = int(np.floor(k)), min(int(np.floor(k)) + 1, len(self.N) - 1)
        w = k - k0
        prof = (1 - w) * self.I[k0] + w * self.I[k1]
        # beyond the table the pattern settles to the unobstructed level
        prof = np.append(prof, 1.0)
        return N, prof

    def intensity(self, lam_nm, a_mm, z_m, r_mm):
        """I at radial position r (mm) for a circular obstacle."""
        N, prof = self.profile(lam_nm, a_mm, z_m)
        x = np.asarray(r_mm, dtype=np.float64) / a_mm
        xg = np.append(self.x, self.x[-1] + 0.6)
        return np.interp(np.clip(x, 0.0, xg[-1]), xg, prof)


def axial_intensity_polar(lam_nm, z_m, A_mm, ntheta=4096):
    """Exact on-axis intensity behind an obstacle whose polar radius is A_mm(theta).

    I(0) = | mean_theta exp(i pi A(theta)^2 / (lambda z)) |^2
    (unit free-space intensity; a perfect circle gives exactly 1 -- the spot.)
    """
    A = np.asarray(A_mm, dtype=np.float64)
    th = np.linspace(0.0, 2.0 * np.pi, ntheta, endpoint=False)
    if A.ndim == 0:
        A = np.full_like(th, float(A))
    elif len(A) != ntheta:
        A = np.interp(th, np.linspace(0, 2 * np.pi, len(A), endpoint=False), A)
    lamz = lam_nm * 1e-9 * z_m
    ph = np.pi * (A * 1e-3) ** 2 / lamz
    return float(abs(np.mean(np.exp(1j * ph))) ** 2)


def disk_theta(n=4096):
    return np.linspace(0.0, 2.0 * np.pi, n, endpoint=False)


def irregular_radius(theta, a_mm, s, seed=7):
    """Smooth irregular rim: circle a_mm at s=0, strongly irregular at s=1."""
    rng = np.random.default_rng(seed)
    theta = np.asarray(theta, dtype=np.float64)
    terms = []
    for k in range(3):
        m = [3, 5, 7][k]
        amp = [0.11, 0.075, 0.05][k]
        ph = float(rng.uniform(0, 2 * np.pi))
        terms.append(amp * np.sin(m * theta + ph))
    mod = sum(terms)
    return a_mm * (1.0 + s * mod)


def tonemap(I):
    """Display luminance 0..1 from relative intensity (unit = unobstructed)."""
    return np.clip(I, 0.0, 1.0) ** 0.62


# ------------------------------------------------------------ colour ---------
def wavelength_rgb(nm):
    """Rough sRGB for a monochromatic wavelength (display convenience only)."""
    nm = float(np.clip(nm, 380.0, 780.0))
    if nm < 440:
        r, g, b = -(nm - 440) / 60.0, 0.0, 1.0
    elif nm < 490:
        r, g, b = 0.0, (nm - 440) / 50.0, 1.0
    elif nm < 510:
        r, g, b = 0.0, 1.0, -(nm - 510) / 20.0
    elif nm < 580:
        r, g, b = (nm - 510) / 70.0, 1.0, 0.0
    elif nm < 645:
        r, g, b = 1.0, -(nm - 645) / 65.0, 0.0
    else:
        r, g, b = 1.0, 0.0, 0.0
    if nm > 700:
        f = 0.3 + 0.7 * (780 - nm) / 80.0
        r, g, b = r * f + (1 - f) * 0.35, g, b
    m = max(r, g, b) or 1.0
    return np.array([r, g, b], dtype=np.float64) / m * 0.98 + np.array([0.02, 0.02, 0.03])


# ------------------------------------------------------------ self test ------
def self_test():
    p = Pattern()
    lam, a, z = 632.8, 5.0, 2.0
    N, prof = p.profile(lam, a, z)
    xg = np.append(p.x, p.x[-1] + 0.6)
    print(f"N = {N:.3f} (a^2/(lam z)), table x range 0..{xg[-1]:.2f} (=r/a)")
    print("on-axis intensity (table) :", round(float(np.interp(0.0, xg, prof)), 5))
    print("on-axis closed form       :", round(float(abs(np.exp(1j * np.pi * N)) ** 2), 5))
    xa = np.linspace(0.0, 2.0, 20001)
    Iv = np.interp(xa, xg, prof)
    print("spot half-max radius      : x=%.4f  (%.4f mm)  [0.61 lam z/a = %.4f mm]"
          % (xa[np.argmax(Iv < 0.5 * Iv[0])], xa[np.argmax(Iv < 0.5 * Iv[0])] * a,
             0.61 * lam * 1e-9 * z / (a * 1e-3) * 1e3))
    print("deep shadow mean I 0.3<x<0.9 :", round(float(Iv[(xa > 0.3) & (xa < 0.9)].mean()), 5))
    print("outside mean I 1.3<x<2.0     :", round(float(Iv[(xa > 1.3) & (xa < 2.0)].mean()), 5))
    th = disk_theta()
    for s_ in (0.0, 0.02, 0.05, 0.12, 0.5, 1.0):
        A = irregular_radius(th, a, s_)
        print(f"  irregular s={s_:<5} axial I(0) = {axial_intensity_polar(lam, z, A):.4f}")
    for lam2 in (450.0, 632.8, 800.0):
        N2, pr2 = p.profile(lam2, a, z)
        I2 = np.interp(xa, xg, pr2)
        r = xa[np.argmax(I2 < 0.5 * I2[0])] * a
        print(f"  lam={lam2:6.1f} nm  N={N2:6.2f}  half-max radius = {r:.4f} mm")
    for a2 in (5.0, 7.5, 10.0):
        N2, pr2 = p.profile(lam, a2, z)
        I2 = np.interp(xa, xg, pr2)
        r = xa[np.argmax(I2 < 0.5 * I2[0])] * a2
        print(f"  D  ={2*a2:5.1f} mm  N={N2:6.2f}  half-max radius = {r:.4f} mm")
    print("colours:", [tuple(np.round(wavelength_rgb(v), 2)) for v in (450, 532, 632.8, 800)])


if __name__ == "__main__":
    self_test()
