import os, subprocess, sys, time
HERE = os.path.dirname(os.path.abspath(__file__))
segs = [0, 1, 2, 3, 4, 5, 6]
running = {}
t0 = time.time()
while segs or running:
    while segs and len(running) < 2:
        i = segs.pop(0)
        log = open(os.path.join(HERE, "build", f"log_seg{i+1}.txt"), "w")
        p = subprocess.Popen([sys.executable, "render_seg.py", str(i)], cwd=HERE,
                             stdout=log, stderr=subprocess.STDOUT)
        running[p] = i
    time.sleep(5)
    for p in list(running):
        if p.poll() is not None:
            print(f"seg {running[p]+1} exit={p.returncode} "
                  f"t={time.time()-t0:.0f}s", flush=True)
            running.pop(p)
print("ALL DONE", round(time.time() - t0, 1), "s")
