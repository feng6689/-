# -*- coding: utf-8 -*-
"""Delivery verification: duration / canvas / frame rate / frame count /
loudness / peak / black frames / flicker / frame reproducibility / subtitle
coverage / text-safe-area / narration-in-window."""
import json
import math
import os
import subprocess
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

FPS, W, H, TOTAL = 30, 1920, 1080, 5400
SAFE = (100, 40, 1820, 1045)          # text must stay inside this box


def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)


def shb(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True)


def frames_of(p):
    o = sh(f'ffprobe -v error -count_frames -select_streams v:0 -show_entries '
           f'stream=nb_read_frames -of default=nw=1:nk=1 "{p}"').stdout
    return int(o.strip()) if o.strip().isdigit() else -1


def main():
    final = os.path.join(HERE, "out", "poisson_spot_1080p.mp4")
    rep = []
    f = sh(f'ffprobe -v error -show_entries format=duration -of default=nw=1:nk=1 "{final}"').stdout.strip()
    dur = float(f)
    rep.append(("duration = 180.000 s", abs(dur - 180.0) < 0.02, dur))
    s = sh(f'ffprobe -v error -select_streams v:0 -show_entries '
           f'stream=width,height,r_frame_rate -of default=nw=1 "{final}"').stdout
    w = int([l for l in s.split() if l.startswith("width")][0].split("=")[1])
    h = int([l for l in s.split() if l.startswith("height")][0].split("=")[1])
    fr = [l for l in s.split() if l.startswith("r_frame_rate")][0].split("=")[1]
    rep.append(("canvas 1920x1080", (w, h) == (W, H), f"{w}x{h}"))
    rep.append(("frame rate 30/1", fr == "30/1", fr))
    n = frames_of(final)
    rep.append(("frame count 5400", n == TOTAL, n))

    # ---- loudness / true peak (BS.1770 via ffmpeg ebur128) ----------------
    o = sh(f'ffmpeg -hide_banner -i "{final}" -af ebur128=peak=true -f null - 2>&1').stdout \
        + sh(f'ffmpeg -hide_banner -i "{final}" -af ebur128=peak=true -f null - 2>&1').stderr
    try:
        i_line = [l for l in o.splitlines() if "I:" in l][-1]
        p_line = [l for l in o.splitlines() if "Peak:" in l][-1]
        lufs = float(i_line.split("I:")[-1].split("LUFS")[0])
        tp = float(p_line.split("Peak:")[-1].split("dBFS")[0])
    except Exception:
        lufs, tp = float("nan"), float("nan")
    rep.append(("integrated loudness -16 LUFS (+/-0.6)", abs(lufs + 16.0) <= 0.6, lufs))
    rep.append(("true peak <= -1 dBTP", tp <= -1.0, tp))

    # ---- decode a downscaled grey stream for frame-level statistics -------
    raw = shb(f'ffmpeg -v error -i "{final}" -vf scale=192:108,format=gray -f rawvideo -').stdout
    buf = np.frombuffer(raw, dtype=np.uint8)
    nfr = len(buf) // (192 * 108)
    g = buf[:nfr * 192 * 108].reshape(nfr, 108, 192).astype(np.float32)
    means = g.mean(axis=(1, 2))
    diffs = np.abs(np.diff(g, axis=0)).mean(axis=(1, 2))
    rep.append(("decoded frames == 5400", nfr == TOTAL, nfr))
    rep.append(("no black frame (min frame mean > 4)", float(means.min()) >= 4.0, round(float(means.min()), 2)))
    med = float(np.median(diffs))
    spikes = int((diffs > max(12.0, 6 * med)).sum())
    rep.append(("no abnormal flicker (diff spikes == 0)", spikes == 0,
                f"median diff {med:.2f}, spikes {spikes}, max {float(diffs.max()):.2f}"))

    # ---- narration inside its declared window + subtitle coverage --------
    tl = json.load(open(os.path.join(HERE, "timeline.json"), encoding="utf-8"))
    a = shb(f'ffmpeg -v error -i "{final}" -f f32le -ac 1 -ar 48000 -').stdout
    au = np.frombuffer(a, dtype=np.float32)
    bad = []
    for ln in tl["lines"]:
        s0, s1 = int(ln["start"] * 48000), int(ln["end"] * 48000)
        seg = au[s0:s1]
        r = float(np.sqrt((seg ** 2).mean())) if len(seg) else 0.0
        if r < 0.01:
            bad.append(ln["id"])
    rep.append(("every narration clip audible in its window", not bad, bad or "all 33 ok"))
    rep.append(("subtitle lines == narration lines (33)", len(tl["lines"]) == 33, len(tl["lines"])))

    # ---- frame reproducibility: re-render 5 frames, compare bytes --------
    import stage
    from PIL import Image
    sc = stage.Scene()
    rng = np.random.default_rng(4)
    idxs = sorted(int(x) for x in rng.choice(TOTAL, 5, replace=False))
    mism = []
    for i in idxs:
        t = i / float(FPS)
        a1 = sc.render(t)
        b1 = sc.render(t)
        if not np.array_equal(a1, b1):
            mism.append(i)
        p = os.path.join(HERE, "build", f"repro_{i}.png")
        Image.fromarray(a1).save(p)
        # compare with the same frame decoded from the delivered file
        d = shb(f'ffmpeg -v error -i "{final}" -vf "select=eq(n\\,{i})" -vframes 1 '
                f'-f rawvideo -pix_fmt rgb24 -').stdout
        if d:
            dec = np.frombuffer(d, dtype=np.uint8)[:W * H * 3].reshape(H, W, 3)
            diff = float(np.abs(dec.astype(np.int16) - a1.astype(np.int16)).mean())
            if diff > 6.0:
                mism.append((i, round(diff, 2)))
    rep.append(("deterministic re-render (same t -> same frame)", not mism, mism or f"checked {idxs}"))
    print("repro check frames:", idxs)

    # ---- text safe area (sampled) ---------------------------------------
    worst = None
    credit_bad = None
    for i in range(0, TOTAL, 15):
        sc.text_extents = []
        sc.credit_extents = []
        sc.render(i / float(FPS))
        for (x0, y0, x1, y1) in sc.text_extents:
            if x0 < SAFE[0] or x1 > SAFE[2] or y0 < SAFE[1] or y1 > SAFE[3]:
                if worst is None or abs(x1) > abs(worst[0]):
                    worst = (x1, y1, i, x0, y0)
        for (x0, y0, x1, y1) in sc.credit_extents:
            if x0 < 0 or y0 < 0 or x1 > W or y1 > H:
                credit_bad = (x0, y0, x1, y1, i)
    rep.append(("all meaning-bearing text inside the safe area", worst is None,
                worst or "checked every 15th frame"))
    rep.append(("corner credit line inside the canvas", credit_bad is None,
                credit_bad or "corner mark, inside 1920x1080"))

    print("\n================ delivery verification ================")
    ok = True
    for name, good, val in rep:
        ok &= bool(good)
        print(f"[{'PASS' if good else 'FAIL'}] {name}   -> {val}")
    print("=========================================================")
    print("RESULT:", "ALL CHECKS PASS" if ok else "SOME CHECKS FAILED")
    json.dump([{"check": n, "pass": bool(g), "value": str(v)} for n, g, v in rep],
              open(os.path.join(HERE, "build", "verify_report.json"), "w"), ensure_ascii=False, indent=1)


if __name__ == "__main__":
    main()