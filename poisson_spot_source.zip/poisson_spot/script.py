# -*- coding: utf-8 -*-
"""Narration script, seven beats, camera keyframes and narration-driven cue rules.

Everything here is a pure data description; build_timeline.py resolves it into
timeline.json, which the renderer reads so that picture / narration / subtitles
share one set of times.
"""

FPS = 30
DURATION = 180.0
WIDTH, HEIGHT = 1920, 1080
TOTAL_FRAMES = int(round(DURATION * FPS))  # 5400

# ---------------------------------------------------------------- narration --
# cn : Chinese subtitle line (one line per narration clip)
# en : English subtitle line (concise, not a word-for-word translation)
LINES = [
    # --- beat 1 : the impossible picture ---------------------------------
    dict(id="L01", seg=1, cn="圆盘把光挡住了。",
         en="The disk blocks the light."),
    dict(id="L02", seg=1, cn="可影子的正中心，偏偏有一点光。",
         en="Yet at the very centre of its shadow there is light."),
    dict(id="L03", seg=1, cn="一束单色光，一块不透明的圆盘，一面屏，就这三样。",
         en="One beam, one opaque disk, one screen. That is all."),
    dict(id="L04", seg=1, cn="亮点，就在圆影的正中央。",
         en="The bright spot sits exactly at the centre of the round shadow."),
    dict(id="L05", seg=1, cn="它叫泊松亮斑，也叫阿拉戈亮斑。",
         en="It is called the Poisson spot, also the Arago spot."),
    # --- beat 2 : guess, then fail ---------------------------------------
    dict(id="L06", seg=2, cn="如果光只沿直线走，影子中心会怎样？",
         en="If light only went in straight lines, would the centre stay dark?"),
    dict(id="L07", seg=2, cn="直觉会说：最暗。那里被挡得最严实。",
         en="Intuition says: the darkest place. It is blocked most there."),
    dict(id="L08", seg=2, cn="可真实的亮度分布，在中心反而抬了起来。",
         en="But the real brightness profile rises at the centre."),
    dict(id="L09", seg=2, cn="看这条剖面：几何预期在中心落下，实际结果在中心抬起。",
         en="On this profile geometry predicts a dip; the actual result rises."),
    dict(id="L10", seg=2, cn="最该暗的地方，为什么最亮？",
         en="Why is the place that should be darkest the brightest?"),
    # --- beat 3 : light is a wave ----------------------------------------
    dict(id="L11", seg=3, cn="要讲通它，得先接受：光是波。",
         en="To make sense of it, accept one thing: light is a wave."),
    dict(id="L12", seg=3, cn="惠更斯原理说，波前上的每一点，都可以看成新的子波源。",
         en="Huygens' principle: every point on a wavefront is a new wavelet source."),
    dict(id="L13", seg=3, cn="子波继续向前，在同一个位置相遇、叠加。",
         en="The wavelets travel on and meet at the same places."),
    dict(id="L14", seg=3, cn="同相相遇，波峰叠波峰，变亮；反相相遇，彼此抵消，变暗。",
         en="In phase, crests add and brighten; out of phase they cancel and dim."),
    dict(id="L15", seg=3, cn="决定亮暗的，不只是挡没挡住，还有波如何叠加。",
         en="Brightness is set not only by blocking, but by how waves add up."),
    # --- beat 4 : symmetry ------------------------------------------------
    dict(id="L16", seg=4, cn="影子中心为什么亮？答案在对称。",
         en="Why is the centre bright? The answer is symmetry."),
    dict(id="L17", seg=4, cn="同轴照明时，圆盘边缘上每一点，到影子中心的距离完全相等。",
         en="On axis, every point of the rim is the same distance from the centre."),
    dict(id="L18", seg=4, cn="它们同时发出子波，走过同样长的路程，到达时相位相同。",
         en="Their wavelets travel equal paths and arrive in phase."),
    dict(id="L19", seg=4, cn="于是互相加强，中心就亮了起来。",
         en="So they reinforce one another, and the centre lights up."),
    dict(id="L20", seg=4, cn="把边缘换得不规则，等光程被破坏，中心亮点随之消失。",
         en="Make the rim irregular: equal paths break and the bright centre fades."),
    # --- beat 5 : spot size and fringes ----------------------------------
    dict(id="L21", seg=5, cn="换回圆盘，先看中心亮点和影子里的明暗条纹。",
         en="Back to the round disk: the central spot and faint fringes within."),
    dict(id="L22", seg=5, cn="圆盘直径不变，波长变长，亮斑变大。",
         en="Keep the disk fixed and lengthen the wavelength: the spot grows."),
    dict(id="L23", seg=5, cn="波长不变，圆盘直径变大，亮斑变小。",
         en="Keep the wavelength fixed and enlarge the disk: the spot shrinks."),
    dict(id="L24", seg=5, cn="每次只改一个量，规律才看得清楚。",
         en="Change one thing at a time, and the rule becomes clear."),
    # --- beat 6 : history -------------------------------------------------
    dict(id="L25", seg=6, cn="这件事，是一次反转。",
         en="This story is a reversal."),
    dict(id="L26", seg=6, cn="1818年，法国科学院悬赏征文。",
         en="In 1818 the French Academy set a prize on the nature of light."),
    dict(id="L27", seg=6, cn="菲涅耳用波动说解释了衍射。",
         en="Fresnel explained diffraction with the wave theory."),
    dict(id="L28", seg=6, cn="泊松反问：光是波，中心就该有亮点。",
         en="Poisson objected: if light is a wave, the centre must hold a spot."),
    dict(id="L29", seg=6, cn="他以为，这足以推翻波动说。",
         en="He expected that absurd consequence to refute the wave theory."),
    dict(id="L30", seg=6, cn="阿拉戈做了实验，中心真的出现了亮点。",
         en="Arago ran the experiment and found the spot at the centre."),
    # --- beat 7 : return --------------------------------------------------
    dict(id="L31", seg=7, cn="影子不是几何阻挡的终点。",
         en="A shadow is not simply where geometry stops."),
    dict(id="L32", seg=7, cn="衍射和叠加，决定了它内部的细节。",
         en="Diffraction and interference decide its inner detail."),
    dict(id="L33", seg=7, cn="看似荒谬的预言，只要经得起实验，就能改写直觉。",
         en="An absurd prediction, if it survives the test, can rewrite intuition."),
]

# per-beat narration windows (start of the first clip, latest allowed end)
BEATS = {
    1: dict(t0=0.45, lim=19.6, gap=0.35),
    2: dict(t0=20.60, lim=50.20, gap=0.40),
    3: dict(t0=50.50, lim=85.20, gap=0.35),
    4: dict(t0=85.30, lim=120.20, gap=0.35),
    5: dict(t0=120.40, lim=145.20, gap=0.35),
    6: dict(t0=145.40, lim=167.40, gap=0.35),
    7: dict(t0=167.60, lim=179.75, gap=0.25),
}

# ------------------------------------------------------------- cue rules ----
# (name, ref_line_or_None, rel, offset)  ->  absolute time
#   rel : "start" | "end";  ref None  ->  offset is an absolute time
CUES = [
    ("hook_show", "L01", "start", 0.85),
    ("hook_hide", "L03", "start", -0.30),
    ("spot_tone", None, "abs", 0.30),
    ("title_show", "L05", "start", -0.15),
    ("title_hide", "L05", "end", 2.80),
    ("choice_show", "L06", "start", 1.00),
    ("choice_hide", "L07", "start", 1.10),
    ("intuition_show", "L07", "start", 0.60),
    ("sweep_show", "L08", "start", 0.50),
    ("profile_show", "L09", "start", 0.15),
    ("profile_hide", None, "abs", 50.60),
    ("question_show", "L10", "start", 0.10),
    ("question_hide", None, "abs", 50.40),
    ("wave_morph", "L11", "start", 0.80),
    ("huygens_points", "L12", "start", 0.60),
    ("subwaves", "L13", "start", 0.20),
    ("interference", "L14", "start", 0.30),
    ("map_to_screen", "L15", "start", 0.50),
    ("rim_view", "L16", "start", 0.50),
    ("paths", "L17", "start", 0.30),
    ("equal_path_chip", "L17", "start", 2.00),
    ("pulses", "L18", "start", 0.10),
    ("converge", "L19", "start", 0.90),
    ("deform", "L20", "start", 0.60),
    ("back_round", "L21", "start", 0.25),
    ("lambda_anim", "L22", "start", 0.50),
    ("d_anim", "L23", "start", 0.50),
    ("compare", "L24", "start", 0.30),
    ("history_show", "L25", "start", 0.30),
    ("m_1818", "L26", "start", 0.20),
    ("m_fresnel", "L27", "start", 0.30),
    ("m_poisson", "L28", "start", 0.30),
    ("m_arago", "L29", "start", 0.40),
    ("outro_fade", None, "abs", 166.80),
    ("final_title", "L33", "start", 1.60),
    ("music_choice_gap", None, "abs", 25.60),   # 2.6 s music drop-out for thinking
    ("music_choice_gap_end", None, "abs", 28.20),
    ("music_hold_low", None, "abs", 164.60),    # suspense before Arago
    ("music_hold_low_end", None, "abs", 166.90),
]

# ------------------------------------------------------------ camera ---------
# keyframe: (t, zoom, centre_x, centre_y) -- the base-image point (zoom 1) that
# lands at the centre of the frame.
# disk centre = (880,540) r=104px | screen panel centre = (1460,660) half=250px
# laser = (300,420)             | panel rect = x 1210..1710, y 410..910
CAMERA = [
    (0.00, 4.50, 1440, 660),
    (3.00, 5.20, 1440, 660),
    (8.00, 1.00, 1150, 600),
    (15.00, 1.60, 1321, 685),
    (20.60, 1.60, 1321, 685),
    (21.40, 1.05, 1120, 620),
    (27.60, 1.05, 1120, 620),
    (31.60, 1.45, 1380, 690),
    (37.00, 1.45, 1380, 690),
    (38.60, 1.15, 1150, 630),
    (50.60, 1.15, 1150, 630),
    (51.60, 1.05, 1050, 585),
    (56.20, 1.05, 1050, 585),
    (60.20, 1.20, 1080, 600),
    (70.00, 1.20, 1080, 600),
    (78.00, 1.30, 1160, 620),
    (85.40, 1.30, 1160, 620),
    (86.60, 1.15, 1170, 600),
    (91.00, 1.15, 1170, 600),
    (98.00, 1.40, 1210, 670),
    (108.00, 1.40, 1210, 670),
    (113.20, 1.70, 1250, 720),
    (120.30, 1.70, 1250, 720),
    (121.40, 1.05, 1120, 600),
    (127.60, 1.05, 1120, 600),
    (129.60, 1.35, 1280, 660),
    (134.00, 1.35, 1280, 660),
    (135.60, 1.30, 1250, 650),
    (140.60, 1.30, 1250, 650),
    (141.60, 1.05, 1120, 600),
    (145.30, 1.05, 1120, 600),
    (146.60, 1.10, 1120, 590),
    (166.60, 1.10, 1120, 590),
    (168.40, 1.10, 1120, 590),
    (172.20, 5.00, 1440, 660),
    (180.00, 5.00, 1440, 660),
]

# ------------------------------------------------------- physics constants ---
PHYS = dict(
    lam_nm=632.8,      # He-Ne laser wavelength used by the main narration
    disk_r_mm=5.0,     # disk radius (D = 10 mm)
    z_m=2.0,           # disk -> screen distance
    screen_half_mm=8.0,   # half width of the screen region shown on the panel
    lam_sweep_nm=(450.0, 800.0),
    disk_sweep_mm=(5.0, 7.2),
)