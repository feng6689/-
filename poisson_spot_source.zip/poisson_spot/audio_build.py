# -*- coding: utf-8 -*-
"""Deterministic music / sfx synthesis, narration assembly and final mix.

Everything is generated from the fixed timeline: same input -> same samples.
Music direction: minimal electronic ambience, glass-like tones, restrained low
pulses, ~80 BPM, drop-outs before the thinking beat, the phase reveal and the
Arago confirmation.  A short three-note motif stands for the bright spot.
"""
import json
import math
import os
import subprocess
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
SR = 48000
DUR = 180.0
OUT = os.path.join(HERE, "build", "audio")
N = int(DUR * SR)


def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)


def read_wav48(path):
    """Read a 48k stereo 16-bit wav through ffmpeg pipes -> float array (n,2)."""
    r = subprocess.run(["ffmpeg", "-v", "error", "-i", path, "-f", "f32le",
                        "-ac", "2", "-ar", "48000", "-"], capture_output=True)
    a = np.frombuffer(r.stdout, dtype=np.float32)
    return a.reshape(-1, 2).astype(np.float64)


# --------------------------------------------------------------- primitives --
def env_ad(n, attack, decay, sr=SR):
    a = np.clip(np.arange(n) / max(1, int(attack * sr)), 0, 1)
    d = np.exp(-np.arange(n) / max(1.0, decay * sr))
    return a * d


def bell(f, dur, amp=0.2, decay=0.55, partials=((1.0, 1.0, 1.0), (2.0, 0.42, 1.6),
                                                (2.76, 0.30, 2.1), (5.40, 0.13, 2.8))):
    """Glassy, fast-decaying tone."""
    n = int(dur * SR)
    t = np.arange(n) / SR
    y = np.zeros(n)
    for mult, pa, dd in partials:
        y += pa * np.sin(2 * np.pi * f * mult * t) * np.exp(-t / (decay / dd))
    y *= np.clip(np.arange(n) / (0.004 * SR), 0, 1)
    return y * amp


def pad_chord(freqs, dur, amp=0.08, attack=1.1, release=1.4, detune=0.0035):
    n = int(dur * SR)
    t = np.arange(n) / SR
    y = np.zeros(n)
    for i, f in enumerate(freqs):
        for d in (-detune, detune):
            y += np.sin(2 * np.pi * f * (1 + d) * t + i * 0.7)
            y += 0.25 * np.sin(2 * np.pi * f * 2 * (1 + d) * t + i * 1.3)
    y /= max(1, len(freqs) * 2)
    a = np.clip(t / attack, 0, 1) * np.clip((dur - t) / release, 0, 1)
    return y * a * amp


def noise_sweep(dur, f0, f1, amp=0.05, seed=11, lp=0.35):
    """Soft band-limited sweep used for parameter changes and wave swells."""
    rng = np.random.default_rng(seed)
    n = int(dur * SR)
    x = rng.standard_normal(n)
    # simple one-pole low-pass, fixed coefficients (deterministic)
    y = np.zeros(n)
    acc = 0.0
    for k in range(n):
        acc += lp * (x[k] - acc)
        y[k] = acc
    t = np.arange(n) / SR
    y *= np.clip(t / (0.12 * dur), 0, 1) * np.clip((dur - t) / (0.4 * dur), 0, 1)
    return y * amp


def add(dst, sig, t0, gain=1.0):
    i = int(t0 * SR)
    n = len(sig)
    if i < 0:
        sig = sig[-i:]; i = 0; n = len(sig)
    n = min(n, len(dst) - i)
    if n <= 0:
        return
    dst[i:i + n] += sig[:n] * gain


# ------------------------------------------------------------------ music ----
NOTE = {"A2": 110.0, "C3": 130.81, "D3": 146.83, "E3": 164.81, "F3": 174.61,
        "G3": 196.0, "A3": 220.0, "C4": 261.63, "D4": 293.66, "E4": 329.63,
        "F4": 349.23, "G4": 392.0, "A4": 440.0, "C5": 523.25, "E5": 659.26}
CHORDS = [("A2", "C4", "E4", "C5"), ("F3", "A3", "C4", "E4"),
          ("C3", "E4", "G4", "C5"), ("G3", "C4", "D4", "G4")]
BEAT = 60.0 / 80.0            # 0.75 s
BAR = 4 * BEAT                # 3 s
MOTIF = [659.26, 830.61, 987.77]      # E5, G#5, B5 (bright, clear, three notes)


def music(ev, total=DUR):
    """Return the stereo music bed (n,2) and the sfx track (n,2)."""
    n = int(total * SR)
    pad = np.zeros(n)
    bells = np.zeros(n)
    pulses = np.zeros(n)

    def seg_gain(t, table):
        g = 0.0
        for (t0, t1, v) in table:
            if t0 <= t < t1:
                g = v
                if t - t0 < 1.2:
                    g *= (t - t0) / 1.2
                if t1 - t < 1.2:
                    g *= (t1 - t) / 1.2
        return g

    # arrangement table (start, end, level)
    pad_tab = [(2.5, 26.0, 0.85), (28.2, 52.0, 0.95), (52.0, 104.0, 1.05),
               (104.0, 107.2, 1.20), (107.2, 121.0, 0.80), (121.0, 160.8, 1.05),
               (160.8, 179.4, 1.10)]
    bell_tab = [(50.0, 86.0, 0.55), (98.0, 104.6, 0.85), (120.5, 145.5, 0.45),
                (160.6, 166.0, 0.75), (170.0, 179.4, 0.70)]
    pulse_tab = [(20.5, 50.0, 0.55), (50.0, 86.0, 0.75), (86.0, 120.0, 0.85),
                 (120.0, 145.5, 0.5), (145.5, 164.6, 0.5)]

    # --- pad: a chord every bar, slight detune grows after the deformation
    k = 0
    while k * BAR < total:
        t0 = k * BAR
        ch = CHORDS[k % len(CHORDS)]
        det = 0.0035
        if ev["deform"] <= t0 < ev["back_round"]:
            det = 0.010           # after the rim breaks, the chord drifts apart
        sig = pad_chord([NOTE[x] for x in ch], BAR + 2.2, amp=0.075, detune=det)
        add(pad, sig, t0 - 0.4, seg_gain(t0, pad_tab))
        k += 1

    # --- low pulses on the beat
    t = 0.4
    while t < total:
        g = seg_gain(t, pulse_tab)
        if g > 0:
            nn = int(0.42 * SR)
            tt = np.arange(nn) / SR
            sig = np.sin(2 * np.pi * 55.0 * tt) * np.exp(-tt / 0.13) * 0.16
            add(pulses, sig, t, g * 0.5)
        t += 2 * BEAT

    # --- soft bell layer
    t = 50.6
    while t < 145.0:
        g = seg_gain(t, bell_tab)
        if g > 0:
            f = NOTE["E5"] if (round((t - 50.6) / BEAT) % 4) < 2 else NOTE["C5"]
            add(bells, bell(f, 1.6, amp=0.055, decay=0.5), t, g)
        t += 2 * BEAT

    # --- drop-outs (the thinking gap, the suspense before Arago)
    for (t0, t1) in ((ev["music_choice_gap"], ev["music_choice_gap_end"]),
                     (ev["music_hold_low"], ev["music_hold_low_end"])):
        i0, i1 = int(t0 * SR), int(t1 * SR)
        r = int(0.35 * SR)
        for i in range(i0 - r, i1 + r):
            if 0 <= i < n:
                g = 1.0
                if i0 - r <= i < i0:
                    g = 1 - (i - (i0 - r)) / r
                elif i0 <= i < i1:
                    g = 0.0
                elif i1 <= i < i1 + r:
                    g = (i - i1) / r
                pad[i] *= g; bells[i] *= g; pulses[i] *= g

    bed = pad + 0.75 * pulses + bells

    # ---------------------------------------------------------------- sfx ---
    sfx = np.zeros(n)
    add(sfx, bell(MOTIF[2], 0.9, amp=0.30, decay=0.22), ev["spot_tone"], 1.0)
    add(sfx, noise_sweep(0.9, 0, 0, amp=0.05, seed=3), ev["wave_morph"], 0.9)
    add(sfx, noise_sweep(0.7, 0, 0, amp=0.045, seed=5), ev["subwaves"], 0.9)
    # convergence: rising cluster + chord
    c0 = ev["converge"]
    for i, f in enumerate(MOTIF):
        add(sfx, bell(f, 2.3, amp=0.16, decay=1.1), c0 + 0.28 + i * 0.03, 1.0)
    add(sfx, bell(NOTE["A4"], 2.6, amp=0.13, decay=1.5), c0 + 0.30, 1.0)
    # deformation: soft metallic drift
    add(sfx, noise_sweep(1.6, 0, 0, amp=0.035, seed=9, lp=0.22), ev["deform"], 0.9)
    # parameter slides: identical sound for both sweeps (no pitch-to-wavelength mapping)
    add(sfx, noise_sweep(0.55, 0, 0, amp=0.05, seed=21), ev["lambda_anim"], 0.9)
    add(sfx, noise_sweep(0.55, 0, 0, amp=0.05, seed=21), ev["d_anim"], 0.9)
    # Arago confirmation: motif + resolution
    a0 = ev["m_arago"]
    for i, f in enumerate(MOTIF):
        add(sfx, bell(f, 2.2, amp=0.20, decay=0.95), a0 + 0.45 + i * 0.42, 1.0)
    add(sfx, pad_chord([NOTE["A3"], NOTE["C4"], NOTE["E4"], NOTE["C5"]], 3.4,
                       amp=0.10, attack=0.5, release=1.2), a0 + 0.55, 1.0)
    # closing motif, lighter
    for i, f in enumerate(MOTIF):
        add(sfx, bell(f, 2.0, amp=0.13, decay=1.0), ev["final_title"] - 0.6 + i * 0.40, 1.0)
    add(sfx, pad_chord([NOTE["A3"], NOTE["E4"], NOTE["A4"], NOTE["C5"]], 3.2,
                       amp=0.085, attack=0.6, release=1.6), ev["final_title"] - 0.3, 1.0)

    # gentle mono-safe widening: tiny decorrelated delay on the right channel
    d = int(0.011 * SR)
    bedr = np.concatenate([np.zeros(d), bed[:-d]])
    music_st = np.stack([bed, 0.72 * bed + 0.28 * bedr], axis=1)
    sfxr = np.concatenate([np.zeros(d), sfx[:-d]])
    sfx_st = np.stack([sfx, 0.8 * sfx + 0.2 * sfxr], axis=1)
    return music_st, sfx_st


# ------------------------------------------------------------------ mix ------
def duck_envelope(vo_mono, attack=0.18, release=0.9):
    """1.0 = no ducking, 0.5 = -6 dB, driven by the narration envelope."""
    win = int(0.035 * SR)
    k = np.ones(win) / win
    rms = np.sqrt(np.convolve(vo_mono ** 2, k, mode="same") + 1e-12)
    thr = 0.012
    target = np.where(rms > thr, 0.50, 1.0)
    # smooth: fast attack when the voice starts, slower release
    out = np.empty_like(target)
    prev = 1.0
    a_c = math.exp(-1.0 / (attack * SR))
    r_c = math.exp(-1.0 / (release * SR))
    for i in range(len(target)):
        c = a_c if target[i] < prev else r_c
        prev = c * prev + (1 - c) * target[i]
        out[i] = prev
    return out


def build():
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(HERE, "timeline.json"), encoding="utf-8") as fh:
        tl = json.load(fh)
    ev = tl["events"]

    vo = np.zeros((N, 2))
    for ln in tl["lines"]:
        w = read_wav48(ln["wav"])
        add2d = int(ln["start"] * SR)
        f = min(int(0.25 * SR), len(w))
        w[:f] *= np.linspace(0, 1, f)[:, None]
        e = min(int(0.25 * SR), len(w))
        w[len(w) - e:] *= np.linspace(1, 0, e)[:, None]
        n = min(len(w), N - add2d)
        vo[add2d:add2d + n] += w[:n]

    mus, sfx = music(ev)
    duck = duck_envelope(vo.mean(axis=1))
    mix = vo * 1.0 + mus * duck[:, None] * 1.0 + sfx * 0.9

    # safety: nothing may clip before normalisation
    peak = np.max(np.abs(mix))
    if peak > 0.99:
        mix *= 0.99 / peak
    np.save(os.path.join(OUT, "vo.npy"), vo.astype(np.float32))
    np.save(os.path.join(OUT, "music.npy"), mus.astype(np.float32))
    np.save(os.path.join(OUT, "mix_raw.npy"), mix.astype(np.float32))

    wr = os.path.join(OUT, "mix_raw.wav")
    x = np.clip(mix, -1, 1)
    data = (x * 32767.0).astype("<i2").tobytes()
    with open(wr, "wb") as fh:
        fh.write(b"RIFF" + (36 + len(data)).to_bytes(4, "little") + b"WAVEfmt ")
        fh.write((16).to_bytes(4, "little") + (1).to_bytes(2, "little")
                 + (2).to_bytes(2, "little") + SR.to_bytes(4, "little")
                 + (SR * 4).to_bytes(4, "little") + (4).to_bytes(2, "little")
                 + (16).to_bytes(2, "little") + b"data" + len(data).to_bytes(4, "little"))
        fh.write(data)
    print("mix_raw.wav written:", wr, "vo/music rms:",
          round(float(np.sqrt((vo ** 2).mean())), 4), round(float(np.sqrt((mus ** 2).mean())), 4))

    # ---- two-pass loudness normalisation to -16 LUFS / -1 dBTP -------------
    r = sh(f'ffmpeg -hide_banner -i "{wr}" -af loudnorm=I=-16:TP=-1:LRA=11:print_format=json -f null -')
    js = r.stderr[r.stderr.rfind("{"):r.stderr.rfind("}") + 1]
    m = json.loads(js)
    print("measured:", {k: m[k] for k in ("input_i", "input_tp", "input_lra", "input_thresh")})
    dst = os.path.join(OUT, "mix.wav")
    r2 = sh(f'ffmpeg -y -hide_banner -v error -i "{wr}" -af '
            f'loudnorm=I=-16:TP=-1:LRA=11:measured_I={m["input_i"]}:'
            f'measured_TP={m["input_tp"]}:measured_LRA={m["input_lra"]}:'
            f'measured_thresh={m["input_thresh"]}:offset={m["target_offset"]}:linear=true '
            f'-ar 48000 -ac 2 -c:a pcm_s16le "{dst}"')
    if not os.path.exists(dst):
        print("loudnorm failed", r2.stderr[-400:])
    else:
        print("mix.wav written:", dst)


if __name__ == "__main__":
    build()