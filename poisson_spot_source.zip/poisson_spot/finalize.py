# -*- coding: utf-8 -*-
"""Concatenate the seven rendered parts, mux the mix, verify, and make the still."""
import json
import os
import subprocess
import sys
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

FPS, W, H = 30, 1920, 1080
TOTAL = 5400
BOUNDS = [0, 600, 1500, 2550, 3600, 4350, 5100, 5400]


def sh(cmd):
    return subprocess.run(cmd, shell=True, capture_output=True, text=True)


def probe(path, entries="format=duration:stream=width,height,r_frame_rate,nb_frames,codec_name", stream=True):
    sel = "-select_streams v:0 " if stream else ""
    return sh(f'ffprobe -v error {sel}-show_entries {entries} -of default=nw=1 "{path}"').stdout


def frames(path):
    out = sh(f'ffprobe -v error -count_frames -select_streams v:0 -show_entries '
             f'stream=nb_read_frames -of default=nw=1:nk=1 "{path}"').stdout
    try:
        return int(out.strip())
    except Exception:
        return -1


def main():
    parts = [os.path.join(HERE, "build", "parts", f"seg{i+1}.mp4") for i in range(7)]
    for i, p in enumerate(parts):
        n = frames(p)
        exp = BOUNDS[i + 1] - BOUNDS[i]
        print(f"part {i+1}: {n} frames (expected {exp}) {'OK' if n == exp else 'MISMATCH'}")
        if n != exp:
            raise SystemExit("missing part")

    lst = os.path.join(HERE, "build", "concat.txt")
    with open(lst, "w") as fh:
        for p in parts:
            fh.write(f"file '{p}'\n")
    video = os.path.join(HERE, "out", "video_only.mp4")
    os.makedirs(os.path.dirname(video), exist_ok=True)
    r = sh(f'ffmpeg -y -v error -f concat -safe 0 -i "{lst}" -c copy "{video}"')
    if not os.path.exists(video):
        raise SystemExit("concat failed: " + r.stderr[-400:])
    print("concatenated:", frames(video), "frames |", probe(video).replace("\n", " "))

    audio = os.path.join(HERE, "build", "audio", "mix.wav")
    final = os.path.join(HERE, "out", "poisson_spot_1080p.mp4")
    r = sh(f'ffmpeg -y -v error -i "{video}" -i "{audio}" -map 0:v:0 -map 1:a:0 '
           f'-c:v copy -c:a aac -b:a 192k -ar 48000 -ac 2 -shortest '
           f'-movflags +faststart "{final}"')
    if not os.path.exists(final):
        raise SystemExit("mux failed: " + r.stderr[-400:])
    print("final:", final)
    print(probe(final).replace("\n", " "))
    print("audio:", sh(f'ffprobe -v error -select_streams a:0 -show_entries '
                       f'stream=codec_name,sample_rate,channels,bit_rate -of default=nw=1 "{final}"').stdout)

    # ---- still frame for delivery (t = 16 s) -----------------------------
    import stage
    sc = stage.Scene()
    from PIL import Image
    arr = sc.render(16.0)
    still = os.path.join(HERE, "out", "still_t16.png")
    Image.fromarray(arr).save(still)
    print("still:", still)


if __name__ == "__main__":
    main()