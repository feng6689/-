# -*- coding: utf-8 -*-
"""Deterministic renderer for the 180 s / 1920x1080 / 30 fps Poisson-spot film.

Every frame is a pure function of time t (no accumulated state, no randomness
outside fixed seeds).  Screen patterns come from physics.py (Fresnel integrals);
everything else is vector / text drawing with PIL + numpy compositing.
"""
import json
import math
import os

import numpy as np
from PIL import Image, ImageDraw, ImageFilter, ImageFont

import physics

HERE = os.path.dirname(os.path.abspath(__file__))
W, H = 1920, 1080
FONT_CN = "/usr/share/fonts/truetype/droid/DroidSansFallbackFull.ttf"
FONT_EN = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"
FONT_ENB = "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf"

# ----------------------------------------------------------- stage geometry --
DISK = np.array([880.0, 540.0])
PANELC = np.array([1440.0, 660.0])
LASER = np.array([320.0, 420.0])
PANEL_HALF = 250.0
PANEL_RECT = (PANELC[0] - PANEL_HALF, PANELC[1] - PANEL_HALF,
              PANELC[0] + PANEL_HALF, PANELC[1] + PANEL_HALF)
EX = np.array([350.0, 75.0])     # +X direction in image space (world -> screen)
SC = 250.0                       # px per world unit along Y / Z  (zoom 1)
X_LASER, X_SCREEN = -1.6, 1.6

C_BG = (0.010, 0.012, 0.018)
C_CN = (240, 244, 250)
C_EN = (196, 206, 220)
C_DIM = (150, 162, 178)
C_ACC = (255, 226, 150)
C_CHIP = (186, 214, 255)

AXIS = EX / np.linalg.norm(EX)
AXIS_ANG = math.degrees(math.atan2(AXIS[1], AXIS[0]))   # ~11.7 deg, PIL angles


def clip01(x):
    return 0.0 if x < 0 else (1.0 if x > 1 else float(x))


def smooth(x):
    x = clip01(x)
    return x * x * (3 - 2 * x)


def ease_in_out(x):
    x = clip01(x)
    return 0.5 - 0.5 * math.cos(math.pi * x)


def env(t, t0, t1, rise=0.5, fall=0.6):
    """Trapezoidal visibility envelope."""
    if t < t0 or t > t1:
        return 0.0
    return min(clip01((t - t0) / rise) if rise > 0 else 1.0,
               clip01((t1 - t) / fall) if fall > 0 else 1.0)


def lerp(a, b, p):
    return a + (b - a) * p



CJK_RANGES = ((0x2E80, 0x303F), (0x3040, 0x30FF), (0x3100, 0x33FF), (0x3400, 0x4DBF),
              (0x4E00, 0x9FFF), (0xF900, 0xFAFF), (0xFE30, 0xFE4F), (0xFF00, 0xFFEF),
              (0x20000, 0x2FA1F))


def is_cjk(ch):
    o = ord(ch)
    return any(a <= o <= b for a, b in CJK_RANGES)


def mixed_runs(text):
    runs, cur, curc = [], "", None
    for ch in text:
        c = is_cjk(ch)
        if curc is None or c == curc:
            cur += ch
            curc = c
        else:
            runs.append((cur, curc))
            cur, curc = ch, c
    if cur:
        runs.append((cur, curc))
    return runs


class Scene:
    def __init__(self, tl_file=None):
        tl_file = tl_file or os.path.join(HERE, "timeline.json")
        with open(tl_file, encoding="utf-8") as fh:
            self.tl = json.load(fh)
        self.lines = self.tl["lines"]
        self.ev = self.tl["events"]
        self.phys = self.tl["phys"]
        self.cam_kf = self.tl["camera"]
        self.pat = physics.Pattern()
        self._fc = {}
        self.bg = self._make_bg()
        self.uniform = {}          # (lam, a) -> dense radial LUT
        self.RMAX = self.phys["screen_half_mm"] * math.sqrt(2.0)
        self.NLUT = 4096
        self.rgrid = np.linspace(0.0, self.RMAX, self.NLUT)
        self.rstep = self.rgrid[1] - self.rgrid[0]
        self.r_inv = 1.0 / self.rstep
        self.theta = physics.disk_theta(720)
        self.ireg = physics.irregular_radius(self.theta, 1.0, 1.0)
        self._cam_cache = {}
        self.text_extents = []
        self.credit_extents = []

    # ---------------------------------------------------------- background --
    def _make_bg(self):
        y, x = np.mgrid[0:H, 0:W].astype(np.float32)
        dx = (x - W * 0.5) / (W * 0.5)
        dy = (y - H * 0.5) / (H * 0.5)
        r = np.sqrt(dx * dx + dy * dy)
        glow = 0.030 * np.exp(-(r * 1.25) ** 2)
        cv = np.empty((H, W, 3), np.float32)
        cv[..., 0] = C_BG[0] + glow * 0.85
        cv[..., 1] = C_BG[1] + glow * 1.00
        cv[..., 2] = C_BG[2] + glow * 1.35
        band = np.clip((y - 820.0) / 260.0, 0.0, 1.0)[..., None] * 0.055
        cv += band * np.array([0.30, 0.36, 0.50], np.float32)
        return cv

    # -------------------------------------------------------------- fonts ---
    def font(self, size, cn=False, bold=False):
        key = (size, cn, bold)
        if key not in self._fc:
            path = FONT_CN if cn else (FONT_ENB if bold else FONT_EN)
            self._fc[key] = ImageFont.truetype(path, size)
        return self._fc[key]

    # ------------------------------------------------------------- camera ---
    def camera(self, t):
        kf = self.cam_kf
        if t <= kf[0][0]:
            k = kf[0]
            return (k[1], k[2], k[3])
        for i in range(len(kf) - 1):
            t0, z0, x0, y0 = kf[i]
            t1, z1, x1, y1 = kf[i + 1]
            if t0 <= t <= t1:
                if t1 - t0 < 1e-9:
                    p = 1.0
                else:
                    p = smooth((t - t0) / (t1 - t0))
                return (lerp(z0, z1, p), lerp(x0, x1, p), lerp(y0, y1, p))
        k = kf[-1]
        return (k[1], k[2], k[3])

    def proj(self, pts, cam):
        """pts: (N,3) world -> (N,2) image."""
        pts = np.asarray(pts, np.float64)
        z, cx, cy = cam
        bx = DISK[0] + SC * pts[:, 2] + EX[0] * pts[:, 0]
        by = DISK[1] - SC * pts[:, 1] + EX[1] * pts[:, 0]
        ix = 960.0 + (bx - cx) * z
        iy = 540.0 + (by - cy) * z
        return np.stack([ix, iy], axis=1)

    def panel_rect_img(self, cam):
        z, cx, cy = cam
        x0 = 960.0 + (PANEL_RECT[0] - cx) * z
        x1 = 960.0 + (PANEL_RECT[2] - cx) * z
        y0 = 540.0 + (PANEL_RECT[1] - cy) * z
        y1 = 540.0 + (PANEL_RECT[3] - cy) * z
        return x0, y0, x1, y1

    def px_per_mm(self, cam):
        return SC / self.phys["screen_half_mm"] * cam[0]

    def world_radius(self, a_mm):
        return a_mm / self.phys["screen_half_mm"]

    # ------------------------------------------------------------- state ----
    def state(self, t):
        ev = self.ev
        st = {"t": t, "cam": self.camera(t)}
        lam = self.phys["lam_nm"]
        a = self.phys["disk_r_mm"]
        if t >= ev["lambda_anim"]:
            p = ease_in_out(clip01((t - ev["lambda_anim"]) / 1.7))
            lam = lerp(self.phys["lam_sweep_nm"][0], self.phys["lam_sweep_nm"][1], p)
        if t >= ev["d_anim"]:
            p = ease_in_out(clip01((t - ev["d_anim"]) / 1.7))
            a = lerp(*self.phys["disk_sweep_mm"], p)
        st["lam_nm"] = lam
        st["a_mm"] = a
        st["d_mm"] = 2 * a
        if t < ev["deform"]:
            st["deform_s"] = 0.0
        elif t < ev["back_round"] - 0.4:
            st["deform_s"] = smooth(clip01((t - ev["deform"]) / 1.6))
        else:   # the round disk comes back for the parameter experiments
            st["deform_s"] = 1.0 - smooth(clip01((t - (ev["back_round"] - 0.4)) / 0.9))
        st["beam_rgb"] = physics.wavelength_rgb(lam)
        z_m = self.phys["z_m"]
        st["panel_gain"] = 1.0
        if ev["wave_morph"] <= t < ev["map_to_screen"]:
            st["panel_gain"] = 0.75
        if t >= ev["m_poisson"] + 0.40:                    # Poisson's prediction: dark centre
            h0 = ev["m_poisson"] + 0.40
            h1 = ev["m_arago"]
            st["panel_gain"] = 1.0
            if h0 <= t <= h1:
                st["spot_dark"] = clip01((t - h0) / 0.5) * clip01((h1 - t) / 0.25)
        if t >= ev["outro_fade"]:
            st["outro"] = clip01((t - ev["outro_fade"]) / 1.0)
        # computed axial intensity behind the deformed obstacle
        if st["deform_s"] > 0:
            A = a * (1.0 + st["deform_s"] * (self.ireg - 1.0))
            st["i0"] = physics.axial_intensity_polar(lam, z_m, A)
        else:
            st["i0"] = 1.0
        st["i0"] = max(st["i0"], 0.0)
        return st

    # ----------------------------------------------------- radial profile ---
    def lut(self, lam, a, z_m):
        key = (round(lam, 1), round(a, 3))
        if key not in self.uniform:
            prof = self.pat.intensity(lam, a, z_m, self.rgrid)
            self.uniform[key] = np.clip(prof, 0.0, 4.0).astype(np.float32)
        return self.uniform[key]

    # ------------------------------------------------------------ drawing ---
    def new_rgba(self, box):
        x0, y0, x1, y1 = [int(round(v)) for v in box]
        x0 = max(0, min(W, x0)); x1 = max(0, min(W, x1))
        y0 = max(0, min(H, y0)); y1 = max(0, min(H, y1))
        if x1 <= x0 or y1 <= y0:
            return None, (0, 0)
        return Image.new("RGBA", (x1 - x0, y1 - y0), (0, 0, 0, 0)), (x0, y0)

    def add_light(self, light, img, pos, gain=1.0, blur=0.0):
        if img is None:
            return
        if blur:
            img = img.filter(ImageFilter.GaussianBlur(blur))
        a = np.asarray(img, np.float32) * (1.0 / 255.0)
        x0, y0 = pos
        h, w = a.shape[:2]
        x0c, y0c = max(0, x0), max(0, y0)
        x1c, y1c = min(W, x0 + w), min(H, y0 + h)
        if x1c <= x0c or y1c <= y0c:
            return
        sub = a[y0c - y0:y1c - y0, x0c - x0:x1c - x0]
        light[y0c:y1c, x0c:x1c] += sub[..., :3] * sub[..., 3:4] * gain

    def over_arr(self, cv, img, pos):
        if img is None:
            return
        a = np.asarray(img, np.float32) * (1.0 / 255.0)
        x0, y0 = pos
        h, w = a.shape[:2]
        x0c, y0c = max(0, x0), max(0, y0)
        x1c, y1c = min(W, x0 + w), min(H, y0 + h)
        if x1c <= x0c or y1c <= y0c:
            return
        sub = a[y0c - y0:y1c - y0, x0c - x0:x1c - x0]
        dst = cv[y0c:y1c, x0c:x1c]
        al = sub[..., 3:4]
        dst *= (1.0 - al)
        dst += sub[..., :3] * al

    def paste_pil(self, dst, img, pos):
        """Alpha-composite a small RGBA layer onto another PIL image."""
        if img is None:
            return
        x0, y0 = int(pos[0]), int(pos[1])
        w, h = img.size
        sx0, sy0 = max(0, -x0), max(0, -y0)
        sx1, sy1 = min(w, W - x0), min(h, H - y0)
        if sx1 <= sx0 or sy1 <= sy0:
            return
        sub = img.crop((sx0, sy0, sx1, sy1))
        dx, dy = x0 + sx0, y0 + sy0
        region = dst.crop((dx, dy, dx + sub.size[0], dy + sub.size[1]))
        dst.paste(Image.alpha_composite(region, sub), (dx, dy))


    def draw_mixed(self, d, xy, text, size, fill, anchor="lt", bold=False):
        """Draw text with per-character font fallback: CJK -> Droid, rest -> DejaVu.

        Droid Sans Fallback carries no Latin/digit/symbol glyphs and DejaVu Sans
        carries no CJK, so every string is split into runs and rendered with the
        font that actually has the glyphs.
        """
        runs = mixed_runs(text)
        fonts = [self.font(size, cn=cn, bold=bold) for _, cn in runs]
        widths = [d.textlength(r, font=f) for (r, _), f in zip(runs, fonts)]
        total = sum(widths)
        x, y = float(xy[0]), float(xy[1])
        if anchor[0] == "m":
            x -= total / 2.0
        elif anchor[0] == "r":
            x -= total
        va = anchor[1] if len(anchor) > 1 else "t"
        for (r, _), f, w in zip(runs, fonts, widths):
            d.text((x, y), r, font=f, fill=fill, anchor="l" + va)
            x += w
        return total

    def mixed_width(self, d, text, size, bold=False):
        runs = mixed_runs(text)
        return sum(d.textlength(r, font=self.font(size, cn=cn, bold=bold)) for r, cn in runs)

    # ---- text helpers -----------------------------------------------------
    def text_lines(self, d, items, cx, cy, align="center", spacing=1.0):
        """items: list of dict(text,size,cn,color,alpha,bold). Returns bbox."""
        hs = []
        for it in items:
            sz = it["size"]
            hgt = sz * (1.30 if it["cn"] else 1.22)
            hs.append(hgt)
        total = sum(hs) * spacing
        y = cy - total / 2.0
        boxes = []
        for it, hgt in zip(items, hs):
            sz = it["size"]
            col = tuple(it["color"]) + (int(255 * it.get("alpha", 1.0)),)
            wpx = self.mixed_width(d, it["text"], sz, bold=it.get("bold", False))
            anch = "mm" if align == "center" else "lm"
            x = cx if align == "center" else (cx - wpx / 2.0 if align == "left" else cx)
            ymid = y + hgt * spacing / 2.0
            if it.get("shadow", True):
                sh = tuple(int(max(0, c * 0.25)) for c in it["color"]) + (int(150 * it.get("alpha", 1.0)),)
                self.draw_mixed(d, (x + 2, ymid + 2), it["text"], sz, sh, anchor=anch)
            self.draw_mixed(d, (x, ymid), it["text"], sz, col, anchor=anch)
            if align == "left":
                boxes.append((x, x + wpx))
            else:
                boxes.append((x - wpx / 2.0, x + wpx / 2.0))
            y += hgt * spacing
        return boxes, (cy - total / 2.0, cy + total / 2.0)

    def track_text(self, boxes, ybox):
        for b in boxes:
            self.text_extents.append((b[0], ybox[0], b[1], ybox[1]))

    def chip(self, cv, text_cn, text_en, xy, anchor="lt", accent=C_CHIP, alpha=0.92):
        d0 = ImageDraw.Draw(Image.new("RGBA", (10, 10)))
        w1 = self.mixed_width(d0, text_cn, 28) if text_cn else 0
        w2 = self.mixed_width(d0, text_en, 24) if text_en else 0
        w = max(w1, w2) + 34
        h = (44 if text_cn else 0) + (36 if text_en else 0) + 18
        x0, y0 = xy
        if anchor == "rb":
            x0, y0 = x0 - w, y0 - h
        elif anchor == "rt":
            x0, y0 = x0 - w, y0
        elif anchor == "lb":
            x0, y0 = x0, y0 - h
        elif anchor == "mt":
            x0, y0 = x0 - w / 2.0, y0
        elif anchor == "mb":
            x0, y0 = x0 - w / 2.0, y0 - h
        # never let a label leave the safe area
        x0 = min(max(104.0, x0), 1816.0 - w)
        y0 = min(max(44.0, y0), 1040.0 - h)
        img, pos = self.new_rgba((x0 - 4, y0 - 4, x0 + w + 4, y0 + h + 4))
        if img is None:
            return
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([4, 4, w + 4, h + 4], radius=14,
                            fill=(10, 14, 22, int(210 * alpha)),
                            outline=tuple(accent) + (110,), width=2)
        if text_cn:
            self.draw_mixed(d, (21, 10), text_cn, 28, C_CN + (250,))
        if text_en:
            self.draw_mixed(d, (21, 10 + (44 if text_cn else 0)), text_en, 24, C_EN + (235,))
        self.paste_pil(cv, img, pos)
        self.track_text([(x0, x0 + w)], (y0, y0 + h))

    # ====================================================== main render =====
    def render(self, t):
        cv = self.bg.copy()
        light = np.zeros((H, W, 3), np.float32)
        st = self.state(t)
        cam = st["cam"]
        gfx, gpos = Image.new("RGBA", (W, H), (0, 0, 0, 0)), (0, 0)
        gd = ImageDraw.Draw(gfx)
        lines_img, lpos = Image.new("RGBA", (W, H), (0, 0, 0, 0)), (0, 0)
        ld = ImageDraw.Draw(lines_img)

        self.draw_panel(cv, st)
        self.draw_beam(light, st)
        self.draw_wave(light, lines_img, ld, st)
        self.draw_disk(gfx, gd, st)
        self.draw_paths(light, lines_img, ld, st)
        self.draw_history(gfx, gd, st)
        self.draw_annotations(gfx, gd, st)
        self.draw_overlays(gfx, gd, st)
        self.draw_subtitles(gfx, gd, st)
        self.draw_code_label(gfx, gd, st)

        cv += light
        self.over_arr(cv, lines_img, lpos)
        self.over_arr(cv, gfx, gpos)
        return np.clip(cv * 255.0 + 0.5, 0, 255).astype(np.uint8)

    # ------------------------------------------------------------- panel ----
    def draw_panel(self, cv, st):
        cam = st["cam"]
        x0, y0, x1, y1 = self.panel_rect_img(cam)
        ix0, iy0 = int(max(0, math.floor(x0))), int(max(0, math.floor(y0)))
        ix1, iy1 = int(min(W, math.ceil(x1))), int(min(H, math.ceil(y1)))
        if ix1 <= ix0 or iy1 <= iy0:
            return
        # world u (Z) and v (Y) of every pixel in the panel rect
        u = ((cam[1] + (np.arange(ix0, ix1) + 0.5 - 960.0) / cam[0]) - PANELC[0]) / SC
        v = (PANELC[1] - (cam[2] + (np.arange(iy0, iy1) + 0.5 - 540.0) / cam[0])) / SC
        r_mm = np.sqrt(u[None, :] ** 2 + v[:, None] ** 2) * self.phys["screen_half_mm"]
        L = self.lut(st["lam_nm"], st["a_mm"], self.phys["z_m"])
        idx = np.clip((r_mm * self.r_inv).astype(np.int32), 0, self.NLUT - 1)
        I = L[idx]
        disp = physics.tonemap(I) * st["panel_gain"]
        if st["deform_s"] > 0:
            core = np.exp(-((r_mm / 0.55) ** 2))
            disp = disp * (1.0 - (1.0 - st["i0"]) * core)
        if st.get("spot_dark"):
            core = np.exp(-((r_mm / 0.9) ** 2))
            disp = disp * (1.0 - 0.96 * st["spot_dark"] * core)
        rgb = disp[..., None] * st["beam_rgb"][None, None, :] * 0.95 + 0.012
        cv[iy0:iy1, ix0:ix1] = rgb.astype(np.float32)

    # -------------------------------------------------------------- beam ----
    def draw_beam(self, light, st):
        cam = st["cam"]
        z = cam[0]
        p_l = self.proj([(X_LASER, 0, 0)], cam)[0]
        p_d = self.proj([(0, 0, 0)], cam)[0]
        p_s = self.proj([(X_SCREEN, 0, 0)], cam)[0]
        r_d = self.world_radius(st["a_mm"]) * 1.14
        w_l = 0.012 * SC * z * 3.0
        m = smooth(clip01((st["t"] - self.ev["wave_morph"]) / 2.6))
        x0 = max(0, int(min(p_l[0] - 40, p_s[0] - 40)))
        x1 = min(W, int(max(p_l[0] + 40, p_s[0] + 40)))
        y0 = max(0, int(min(p_l[1], p_s[1]) - r_d * SC * z - 40))
        y1 = min(H, int(max(p_l[1], p_s[1]) + r_d * SC * z + 40))
        if x1 <= x0 or y1 <= y0:
            return
        ys, xs = np.mgrid[y0:y1, x0:x1]
        px = xs + 0.5 - p_d[0]
        py = ys + 0.5 - p_d[1]
        s = px * AXIS[0] + py * AXIS[1]                    # along the axis
        d = -px * AXIS[1] + py * AXIS[0]                   # perpendicular
        sl = (p_l - p_d)
        s_l = float(s.min() - 10)
        s_las = float(sl[0] * AXIS[0] + sl[1] * AXIS[1])
        s_screen = float((p_s - p_d)[0] * AXIS[0] + (p_s - p_d)[1] * AXIS[1])
        # local half width grows towards the screen
        f = np.clip((s - s_las) / max(1.0, s_screen - s_las), 0.0, 1.4)
        wloc = np.where(s < 0, w_l + (r_d * SC * z - w_l) * np.clip((s - s_las) / max(1.0, -s_las), 0, 1),
                        r_d * SC * z * (1.0 + 0.10 * f))
        prof = np.exp(-((d / np.maximum(wloc, 1.0)) ** 2) * 1.35)
        front = np.clip((s - s_las) / max(1.0, s_las * 0.06), 0, 1)
        fade = np.clip((s_screen * 0.94 - s) / 60.0, 0, 1)
        wave = 0.78 + 0.22 * np.cos(2 * np.pi * (s / 190.0) - 2 * np.pi * 0.55 * st["t"])
        a = prof * front * fade * wave * (1.0 - 0.85 * m)
        col = st["beam_rgb"]
        light[y0:y1, x0:x1, 0] += a * col[0] * 0.72
        light[y0:y1, x0:x1, 1] += a * col[1] * 0.72
        light[y0:y1, x0:x1, 2] += a * col[2] * 0.72

    # ------------------------------------------------- wavefront / wavelet ---
    def draw_wave(self, light, img, d, st):
        t = st["t"]
        cam = st["cam"]
        m = smooth(clip01((t - self.ev["wave_morph"]) / 2.6))
        bm = smooth(clip01((t - self.ev["huygens_points"]) / 1.8))
        sw = smooth(clip01((t - self.ev["subwaves"]) / 1.0))
        fade = 1.0 - smooth(clip01((t - self.ev["back_round"]) / 1.5))
        if m <= 0.001 or fade <= 0.002:
            return
        m *= fade
        bm *= fade
        sw *= fade
        z = cam[0]
        p_l = self.proj([(X_LASER, 0, 0)], cam)[0]
        p_d = self.proj([(0, 0, 0)], cam)[0]
        dist = float(np.linalg.norm(p_d - p_l))
        col = tuple(int(255 * c) for c in np.clip(st["beam_rgb"] * 1.15, 0, 1))
        # --- arcs travelling from the laser towards the disk
        if bm < 0.999:
            for k in range(8):
                ph = (t * 0.30 + k / 8.0) % 1.0
                R = ph * dist * 1.05
                if R < 6:
                    continue
                a = int(150 * m * (1.0 - bm) * (0.35 + 0.65 * (1 - ph)))
                if a <= 2:
                    continue
                d.arc([p_l[0] - R, p_l[1] - R, p_l[0] + R, p_l[1] + R],
                      AXIS_ANG - 78, AXIS_ANG + 78, fill=col + (a,), width=3)
        # --- Huygens points on the rim
        r_d = self.world_radius(st["a_mm"])
        rim = np.stack([np.zeros(len(self.theta)), r_d * np.cos(self.theta),
                        r_d * np.sin(self.theta)], axis=1)
        rim_img = self.proj(rim, cam)
        if bm > 0.001:
            n = len(self.theta)
            k = int(round(bm * 12))
            for i in range(0, n, n // 12):
                j = i // (n // 12)
                on = 1.0 if j < k else 0.35
                x, y = rim_img[i]
                rr = 6.5 * z
                d.ellipse([x - rr, y - rr, x + rr, y + rr],
                          fill=col + (int(215 * bm * on),))
        # --- wavelets expanding from every rim point
        if sw > 0.001:
            zc = self.proj([(0, 0, 0)], cam)[0]
            Rmax = float(np.linalg.norm(self.proj([(X_SCREEN, 0, 0)], cam)[0] - zc)) * 1.06
            for i in range(0, len(self.theta), len(self.theta) // 12):
                x, y = rim_img[i]
                for k in range(3):
                    ph = (t * 0.36 + k / 3.0 + (i / len(self.theta))) % 1.0
                    R = ph * Rmax
                    if R < 8:
                        continue
                    a = int(120 * sw * (1 - ph) ** 1.4)
                    if a <= 2:
                        continue
                    d.arc([x - R, y - R, x + R, y + R], AXIS_ANG - 84, AXIS_ANG + 84,
                          fill=col + (a,), width=2)
        # --- superposition zone (illustrative 2-D wave field, marked "示意")
        iz0, iz1 = self.ev["interference"], self.ev["map_to_screen"]
        if iz0 - 0.2 <= t <= iz1 + 2.0 and fade > 0.02:
            gainz = env(t, iz0 - 0.2, iz1 + 2.0, 0.6, 0.8) * fade
            self.draw_interference(light, st, rim_img, gainz)

    def draw_interference(self, light, st, rim_img, gain):
        cam = st["cam"]
        p_d = self.proj([(0, 0, 0)], cam)[0]
        p_s = self.proj([(X_SCREEN, 0, 0)], cam)[0]
        step = 2
        x0 = max(0, int(min(p_d[0], p_s[0])) - 30)
        x1 = min(W, int(max(p_d[0], p_s[0])) + 60)
        r_d = self.world_radius(st["a_mm"]) * SC * cam[0]
        y0 = max(0, int(min(p_d[1], p_s[1]) - r_d - 60))
        y1 = min(H, int(max(p_d[1], p_s[1]) + r_d + 60))
        if x1 <= x0 or y1 <= y0:
            return
        ys, xs = np.mgrid[y0:y1:step, x0:x1:step]
        field = np.zeros(xs.shape, np.float32)
        lam_px = 74.0
        src = rim_img[::len(self.theta) // 12]
        for sx, sy in src:
            dist = np.sqrt((xs - sx) ** 2 + (ys - sy) ** 2)
            field += np.cos(2 * np.pi * dist / lam_px - 2 * np.pi * 0.42 * st["t"])
        field /= len(src)
        amp = (field + 1.0) * 0.5
        # mask: only between the disk and the screen, softly
        smask = np.clip((xs - (p_d[0] + r_d * 1.02)) / 40.0, 0, 1) * \
            np.clip(((p_s[0] - 14) - xs) / 60.0, 0, 1)
        ymask = np.clip(1.0 - ((ys - p_d[1]) / (r_d * 1.5)) ** 2, 0, 1)
        a = amp * smask * ymask * gain * 0.55
        col = st["beam_rgb"]
        sub = light[y0:y1:step, x0:x1:step]
        for c in range(3):
            sub[..., c] += a * col[c] * 0.9
        # expand by 2x2 repeat
        if step > 1:
            big = np.repeat(np.repeat(sub, step, axis=0), step, axis=1)
            light[y0:y1, x0:x1] = big[:y1 - y0, :x1 - x0]

    # -------------------------------------------------------------- disk ----
    def draw_disk(self, gfx, gd, st):
        cam = st["cam"]
        z = cam[0]
        c = self.proj([(0, 0, 0)], cam)[0]
        a = st["a_mm"]
        r_px = self.world_radius(a) * SC * z
        if st["deform_s"] > 0.001:
            A = a * (1.0 + st["deform_s"] * (self.ireg - 1.0))
            pts = []
            for th, Aa in zip(self.theta, A):
                rr = self.world_radius(Aa) * SC * z
                pts.append((c[0] + rr * math.sin(th), c[1] - rr * math.cos(th)))
            gd.polygon(pts, fill=(22, 26, 34, 255), outline=(150, 168, 190, 255))
            gd.line(pts + [pts[0]], fill=(150, 166, 186, 255), width=3)
        else:
            gd.ellipse([c[0] - r_px, c[1] - r_px, c[0] + r_px, c[1] + r_px],
                       fill=(22, 26, 34, 255), outline=(158, 176, 198, 255), width=4)
            gd.ellipse([c[0] - r_px * 0.82, c[1] - r_px * 0.82,
                        c[0] + r_px * 0.82, c[1] + r_px * 0.82],
                       outline=(52, 60, 72, 200), width=2)
            gd.arc([c[0] - r_px, c[1] - r_px, c[0] + r_px, c[1] + r_px],
                   -205, -65, fill=(206, 222, 240, 170), width=6)
        # stem
        gd.line([c[0], c[1] + r_px + 4, c[0], c[1] + r_px + 76], fill=(78, 86, 98, 210), width=5)

    # ------------------------------------------------------------- paths ----
    def draw_paths(self, light, img, d, st):
        t = st["t"]
        p0, p1 = self.ev["paths"], self.ev["rim_view"]
        if not (p0 - 1.0 <= t <= self.ev["back_round"]):
            return
        cam = st["cam"]
        on = smooth(clip01((t - p0 - 0.9) / 2.4))
        if on <= 0.001:
            return
        c = self.proj([(X_SCREEN, 0, 0)], cam)[0]
        a = st["a_mm"]
        rim = []
        z_m = self.phys["z_m"]
        for th in self.theta[::len(self.theta) // 12]:
            A = a
            if st["deform_s"] > 0.001:
                A = a * (1.0 + st["deform_s"] * (float(physics.irregular_radius(np.array([th]), 1.0, 1.0)[0]) - 1.0))
            rim.append((th, A))
        col = tuple(int(255 * c_) for c_ in np.clip(st["beam_rgb"] * 0.75 + 0.25, 0, 1))
        n = len(rim)
        shown = on * n
        for i, (th, A) in enumerate(rim):
            if i + 1 > shown:
                break
            rr = self.world_radius(A)
            wp = self.proj([(0, rr * math.cos(th), rr * math.sin(th))], cam)[0]
            d.line([wp[0], wp[1], c[0], c[1]], fill=col + (95,), width=2)
        # pulses travelling with the same speed along equal paths
        pu = self.ev["pulses"]
        if pu - 0.1 <= t <= pu + 2.6 and st["deform_s"] < 0.01:
            ph = clip01((t - pu) / 1.25)
            for th, A in rim:
                rr = self.world_radius(A)
                wp = self.proj([(0, rr * math.cos(th), rr * math.sin(th))], cam)[0]
                x = wp[0] + (c[0] - wp[0]) * ph
                y = wp[1] + (c[1] - wp[1]) * ph
                rad = 7 * cam[0]
                d.ellipse([x - rad, y - rad, x + rad, y + rad], fill=(255, 246, 214, 235))
        elif st["deform_s"] > 0.01:
            # after the deformation the wavelets arrive out of step: draw the
            # per-point arrival phase as a short flat marker
            for th, A in rim:
                rr = self.world_radius(A)
                wp = self.proj([(0, rr * math.cos(th), rr * math.sin(th))], cam)[0]
                for k in range(3):
                    f = clip01(0.28 + 0.22 * k + 0.1 * math.sin(th * 3.0))
                    x = wp[0] + (c[0] - wp[0]) * f
                    y = wp[1] + (c[1] - wp[1]) * f
                    rad = 5 * cam[0]
                    d.ellipse([x - rad, y - rad, x + rad, y + rad],
                              fill=(255, 246, 214, 120))

    # ----------------------------------------------------------- history ----
    def draw_history(self, gfx, gd, st):
        t = st["t"]
        t0 = self.ev["history_show"]
        if not (t0 - 0.2 <= t <= self.ev["outro_fade"] + 0.4):
            return
        g = env(t, t0, self.ev["outro_fade"] + 0.4, 0.5, 0.5)
        y = 196
        x0, x1 = 392, 1528
        a = int(180 * g)
        gd.line([x0, y, x1, y], fill=(120, 132, 150, a), width=3)
        marks = [("m_1818", "1818", "French Academy prize"),
                 ("m_fresnel", "菲涅耳 Fresnel", ""),
                 ("m_poisson", "泊松 Poisson", ""),
                 ("m_arago", "阿拉戈 Arago", "")]
        for i, (key, cn, en) in enumerate(marks):
            tm = self.ev[key]
            if t < tm:
                continue
            p = smooth(clip01((t - tm) / 0.5))
            x = x0 + (x1 - x0) * (i / (len(marks) - 1.0))
            pulse = max(0.0, 1.0 - clip01((t - tm) / 0.9))
            r = 9 + 6 * pulse
            gd.ellipse([x - r, y - r, x + r, y + r],
                       fill=(255, 232, 168, int(230 * p * g)),
                       outline=(255, 244, 214, int(200 * p * g)), width=2)
            self.chip(gfx, cn, en, (x, y + 26), anchor="mt",
                      accent=(255, 226, 150), alpha=0.85 * p * g)

    # ------------------------------------------------------- annotations ----
    def draw_annotations(self, gfx, gd, st):
        t = st["t"]
        cam = st["cam"]
        col = tuple(int(255 * c_) for c_ in np.clip(st["beam_rgb"] * 0.8 + 0.2, 0, 1))
        # ---- laser device + labels (beat 1-3)
        if t <= self.ev["map_to_screen"] + 1.0:
            p_l = self.proj([(X_LASER, 0, 0)], cam)[0]
            z = cam[0]
            bw, bh = 40 * z, 26 * z
            gd.rounded_rectangle([p_l[0] - bw, p_l[1] - bh, p_l[0] + bw * 0.2, p_l[1] + bh],
                                 radius=6 * z, fill=(30, 34, 42, 240),
                                 outline=(96, 106, 122, 255), width=2)
            if t <= self.ev["hook_hide"] + 1.0 and 220 < p_l[0] < 1600 and z <= 1.6:
                self.chip(gfx, "单色光源", "monochromatic laser",
                          (p_l[0] + 30 * z, p_l[1] + 40 * z), anchor="lt", alpha=0.8)
        # ---- screen label
        if self.ev["hook_hide"] < t <= self.ev["map_to_screen"]:
            x0, y0, x1, y1 = self.panel_rect_img(cam)
            if x1 - x0 > 320:
                self.chip(gfx, "观察屏", "screen", (x1, y0), anchor="rt", alpha=0.8)
        # ---- disk diameter annotation (beat 5)
        if self.ev["back_round"] <= t < self.ev["compare"] - 0.4:
            self.draw_dims(gfx, gd, st)
        # live core-profile comparison during the two parameter runs
        if t >= self.ev["lambda_anim"] - 1.0:
            self.core_plot(gfx, st)
        if t >= self.ev["compare"]:
            self.compare_card(gfx, gd, st)
        # ---- phasor inset (beat 4)
        if self.ev["rim_view"] - 0.5 <= t <= self.ev["back_round"]:
            self.draw_phasors(gfx, gd, st)

    def draw_dims(self, gfx, gd, st):
        t = st["t"]
        gout = 1.0 - clip01((t - self.ev["outro_fade"]) / 0.8)
        if gout <= 0.02:
            return
        cam = st["cam"]
        a = st["a_mm"]
        c = self.proj([(0, 0, 0)], cam)[0]
        r_px = self.world_radius(a) * SC * cam[0]
        if r_px < 40:
            return
        y = c[1] + r_px + 34
        gd.line([c[0] - r_px, y, c[0] + r_px, y], fill=(190, 206, 226, 220), width=3)
        for sgn in (-1, 1):
            gd.line([c[0] + sgn * r_px, y - 9, c[0] + sgn * r_px, y + 9],
                    fill=(190, 206, 226, 220), width=3)
        grow = t >= self.ev["d_anim"] + 1.7
        lab = f"圆盘直径 D = {st['d_mm']:.0f} mm" if grow else "圆盘直径 D"
        self.chip(gfx, lab, "disk diameter", (c[0], y + 18), anchor="mt", alpha=0.85 * gout)
        # wavelength label on the beam
        p_mid = self.proj([(X_LASER * 0.5, 0, 0)], cam)[0]
        lam = st["lam_nm"]
        lam_lab = f"波长 λ = {lam:.0f} nm" if t >= self.ev["lambda_anim"] - 0.2 else "波长 λ"
        if 210 < p_mid[0] < 1600 and 150 < p_mid[1] < 880:
            self.chip(gfx, lam_lab, "wavelength", (p_mid[0], p_mid[1] - 90 * cam[0]),
                      anchor="mb", alpha=0.85 * gout)
        # fixed rule labels
        if t >= self.ev["lambda_anim"] - 0.1:
            self.chip(gfx, "λ 增大 → 亮斑变大", "longer λ: bigger spot",
                      (1560, 300), anchor="rt", accent=C_ACC, alpha=0.9 * gout)
        if t >= self.ev["d_anim"] - 0.1:
            self.chip(gfx, "D 增大 → 亮斑变小", "bigger disk: smaller spot",
                      (1560, 372), anchor="rt", accent=C_ACC, alpha=0.9 * gout)
        # ruler on the screen (fixed scale reference)
        x0, y0, x1, y1 = self.panel_rect_img(cam)
        if x1 - x0 > 360 and t < self.ev["compare"] - 0.4:
            ppm = self.px_per_mm(cam)
            bx = (x0 + x1) / 2.0 - ppm * 1.6
            by = y1 - 26
            gd.line([bx, by, bx + ppm * 3.2, by], fill=(210, 222, 238, 225), width=3)
            for k in range(5):
                gd.line([bx + ppm * 0.8 * k, by - 7, bx + ppm * 0.8 * k, by + 7],
                        fill=(210, 222, 238, 225), width=3)
            self.chip(gfx, "标尺 0.8 mm", "scale bar", (bx, by - 14), anchor="mb",
                      alpha=0.8 * gout)


    def draw_compare(self, gfx, gd, st):
        g = env(st["t"], self.ev["compare"], self.ev["outro_fade"] + 0.3, 0.6, 0.6)
        if g <= 0.01:
            return
        items = [("λ 小 / short λ", 450.0, 5.0), ("λ 大 / long λ", 800.0, 5.0),
                 ("D 小 / small D", 632.8, 5.0), ("D 大 / large D", 632.8, 10.0)]
        size = 176
        for i, (lab, lam, a) in enumerate(items):
            cx = 300 + i * 320
            cy = 208
            L = self.lut(lam, a, self.phys["z_m"])
            rr = (np.arange(size) - size / 2.0) / size * 2.0 * 3.2   # mm
            R2 = rr[None, :] ** 2 + rr[:, None] ** 2
            rm = np.sqrt(R2)
            idx = np.clip((rm / self.rgrid[-1] * (self.NLUT - 1)).astype(np.int32), 0, self.NLUT - 1)
            I = L[idx]
            disp = physics.tonemap(I)
            col = physics.wavelength_rgb(lam)
            arr = np.clip(disp[..., None] * col[None, None, :] * 0.95 * 255 * g, 0, 255).astype(np.uint8)
            sub = Image.fromarray(arr, "RGB").convert("RGBA")
            sub.putalpha(int(255 * g))
            img, pos = self.new_rgba((cx - size / 2, cy - size / 2,
                                      cx + size / 2, cy + size / 2))
            if img is None:
                continue
            img.paste(sub, (0, 0), sub)
            d = ImageDraw.Draw(img)
            d.rectangle([0, 0, size - 1, size - 1], outline=(190, 205, 225, int(220 * g)), width=2)
            self.paste_pil(gfx, img, pos)
            self.chip(gfx, lab, "", (cx, cy + size / 2 + 12), anchor="mt",
                      alpha=0.85 * g)

    def draw_phasors(self, gfx, gd, st):
        t = st["t"]
        g = env(t, self.ev["rim_view"] - 0.5, self.ev["back_round"], 0.6, 0.8)
        if g <= 0.02:
            return
        a = st["a_mm"]
        ix0, ix1 = 120, 462
        iy0, iy1 = 600, 880
        img, pos = self.new_rgba((ix0, iy0, ix1, iy1))
        if img is None:
            return
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([0, 0, ix1 - ix0, iy1 - iy0], radius=18,
                            fill=(9, 13, 21, int(215 * g)),
                            outline=(150, 170, 200, int(120 * g)), width=2)
        cx, cy = (ix1 - ix0) / 2.0, (iy1 - iy0) / 2.0 + 18
        R = 78
        z_m = self.phys["z_m"]
        dw = clip01((t - self.ev["deform"]) / 1.6)
        ph = []
        for th in self.theta[::len(self.theta) // 12]:
            A = a * (1.0 + dw * (float(physics.irregular_radius(np.array([th]), 1.0, 1.0)[0]) - 1.0))
            p = np.pi * (A * 1e-3) ** 2 / (st["lam_nm"] * 1e-9 * z_m)
            ph.append(p % (2 * np.pi))
        re = float(np.mean(np.cos(ph)))
        im = float(np.mean(np.sin(ph)))
        mag = math.hypot(re, im)
        onset = smooth(clip01((t - self.ev["converge"] + 0.6) / 1.2))
        for p in ph:
            x = cx + math.cos(p) * R * 0.28
            y = cy - math.sin(p) * R * 0.28
            d.line([x, y, x + math.cos(p) * R * 0.62, y - math.sin(p) * R * 0.62],
                   fill=(150, 186, 235, int(215 * g * onset)), width=3)
            d.ellipse([x - 3, y - 3, x + 3, y + 3], fill=(200, 220, 245, int(230 * g * onset)))
        ang = math.atan2(im, re)
        d.line([cx, cy, cx + math.cos(ang) * R * 1.02 * mag,
                cy - math.sin(ang) * R * 1.02 * mag],
               fill=(255, 224, 140, int(240 * g * onset)), width=6)
        self.draw_mixed(d, (18, 12), "相位叠加：子波矢量求和", 26, C_CN + (int(240 * g),))
        self.draw_mixed(d, (18, 44), "phasor sum of the rim wavelets", 20, C_EN + (int(220 * g),))
        self.draw_mixed(d, (18, iy1 - iy0 - 68), f"合力 = {mag:.2f}", 26, (255, 224, 140, int(240 * g)))
        self.draw_mixed(d, (18, iy1 - iy0 - 36), "resultant", 20, C_EN + (int(220 * g),))
        self.paste_pil(gfx, img, pos)


    def core_image(self, lam, a, size, half_mm):
        """Screen-centre close-up (spot core) as an RGB array, fixed real scale."""
        rr = (np.arange(size) - size / 2.0) / (size / 2.0) * half_mm
        R = np.sqrt(rr[None, :] ** 2 + rr[:, None] ** 2)
        L = self.lut(lam, a, self.phys["z_m"])
        idx = np.clip((R * self.r_inv).astype(np.int32), 0, self.NLUT - 1)
        disp = physics.tonemap(L[idx])
        col = physics.wavelength_rgb(lam)
        return np.clip(disp[..., None] * col[None, None, :] * 0.95 * 255, 0, 255).astype(np.uint8)

    def core_plot(self, gfx, st):
        """Live comparison of the spot core profile against a frozen reference."""
        t = st["t"]
        ev = self.ev
        t0 = ev["lambda_anim"] - 0.5
        t1 = ev["d_anim"] + 2.2
        g = env(t, t0, t1, 0.5, 0.6)
        if g <= 0.02:
            return
        if t < ev["d_anim"]:
            ref_lam, ref_a = self.phys["lam_sweep_nm"][0], self.phys["disk_r_mm"]
            ref_lab, cur_lab = f"参考 λ={ref_lam:.0f} nm", f"当前 λ={st['lam_nm']:.0f} nm"
        else:
            ref_lam, ref_a = self.phys["lam_sweep_nm"][1], self.phys["disk_r_mm"]
            ref_lab, cur_lab = (f"参考 D={2*self.phys['disk_r_mm']:.0f} mm",
                                f"当前 D={st['d_mm']:.0f} mm")
        img, pos = self.new_rgba((860, 58, 1660, 244))
        if img is None:
            return
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([0, 0, 800, 186], radius=16, fill=(6, 9, 15, int(205 * g)),
                            outline=(140, 160, 190, int(120 * g)), width=2)
        half = 0.25
        n = 260
        xa = np.linspace(-half, half, n)
        plot_w, plot_h = 470, 84
        ox, oy = 300, 62
        for k in range(3):
            yy = oy + plot_h * k / 2.0
            d.line([ox, yy, ox + plot_w, yy], fill=(70, 80, 96, int(160 * g)), width=1)
        for lab, lam, a, col in ((ref_lab, ref_lam, ref_a, (120, 150, 200)),
                                 (cur_lab, st["lam_nm"], st["a_mm"], (255, 236, 190))):
            pts = []
            for xx in xa:
                I = float(self.pat.intensity(lam, a, self.phys["z_m"], abs(xx)))
                pts.append((ox + plot_w * (xx + half) / (2 * half),
                            oy + plot_h * (1 - min(1.0, I) * 0.92)))
            wdt = 3 if col[0] > 200 else 2
            for k in range(len(pts) - 1):
                d.line([pts[k], pts[k + 1]], fill=col + (int(235 * g),), width=wdt)
        d.line([ox + plot_w / 2, oy - 6, ox + plot_w / 2, oy + plot_h + 6],
               fill=(110, 124, 140, int(170 * g)), width=1)
        self.draw_mixed(d, (18, 14), "亮斑的亮度剖面（同一标尺）", 26, C_CN + (int(240 * g),))
        self.draw_mixed(d, (18, 46), "spot brightness profile, identical scale", 20, C_EN + (int(210 * g),))
        self.draw_mixed(d, (18, 92), ref_lab, 24, (150, 180, 225, int(230 * g)))
        self.draw_mixed(d, (18, 128), cur_lab, 24, (255, 236, 190, int(240 * g)))
        ay = oy + plot_h + 6
        self.draw_mixed(d, (ox, ay), "−0.25 mm", 20, C_EN + (int(200 * g),), anchor="lt")
        self.draw_mixed(d, (ox + plot_w / 2.0, ay), "中心 centre", 20, C_EN + (int(200 * g),), anchor="mt")
        self.draw_mixed(d, (ox + plot_w, ay), "+0.25 mm", 20, C_EN + (int(200 * g),), anchor="rt")
        self.paste_pil(gfx, img, pos)
        self.track_text([(860, 1660)], (58, 244))

    def compare_card(self, gfx, gd, st):
        g = env(st["t"], self.ev["compare"], 145.2, 0.6, 0.8)
        if g <= 0.02:
            return
        items = [("λ 小 / short λ", 450.0, 5.0), ("λ 大 / long λ", 800.0, 5.0),
                 ("D 小 / small D", 632.8, 5.0), ("D 大 / large D", 632.8, 7.2)]
        size, half = 208, 0.25
        card_w, card_h = 2 * size + 96, 2 * size + 150
        cx0, cy0 = 960 - card_w / 2.0, 300
        img, pos = self.new_rgba((cx0, cy0, cx0 + card_w, cy0 + card_h))
        if img is None:
            return
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([0, 0, card_w - 1, card_h - 1], radius=20,
                            fill=(6, 9, 15, int(200 * g)),
                            outline=(150, 170, 200, int(130 * g)), width=2)
        self.draw_mixed(d, (26, 14), "两种变化的结果并置", 30, C_CN + (int(245 * g),))
        self.draw_mixed(d, (26, 52), "two parameter runs, same scale", 20, C_EN + (int(215 * g),))
        for i, (lab, lam, a) in enumerate(items):
            arr = self.core_image(lam, a, size, half)
            sub = Image.fromarray(arr, "RGB").convert("RGBA")
            sub.putalpha(int(255 * g))
            x = 32 + (i % 2) * (size + 32)
            y = 86 + (i // 2) * (size + 66)
            img.paste(sub, (x, y), sub)
            d.rectangle([x, y, x + size - 1, y + size - 1],
                        outline=(170, 188, 210, int(210 * g)), width=2)
            d.line([x + 12, y + size - 20, x + 12 + size * (0.1 / (2 * half)), y + size - 20],
                   fill=(230, 240, 250, int(220 * g)), width=3)
            self.draw_mixed(d, (x + 12, y + size - 16), "0.1 mm", 20, C_EN + (int(210 * g),))
            self.draw_mixed(d, (x, y + size + 6), lab, 24, C_CN + (int(240 * g),))
        self.paste_pil(gfx, img, pos)
        self.track_text([(cx0, cx0 + card_w)], (cy0, cy0 + card_h))


    def superposition_card(self, gfx, gd, st):
        """Magnified view of the wavelet superposition region (marked 示意)."""
        t = st["t"]
        g = env(t, self.ev["interference"] - 0.5, self.ev["map_to_screen"] + 2.0, 0.6, 0.8)
        if g <= 0.02:
            return
        x0, y0, x1, y1 = 500, 58, 1420, 250
        img, pos = self.new_rgba((x0, y0, x1, y1))
        if img is None:
            return
        w, h = x1 - x0, y1 - y0
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([0, 0, w - 1, h - 1], radius=16, fill=(6, 9, 15, int(205 * g)),
                            outline=(150, 170, 200, int(120 * g)), width=2)
        # internal wave field, 12 secondary sources on a vertical line
        iw, ih = 620, 112
        ax0, ay0 = 24, 74
        ys, xs = np.mgrid[0:ih, 0:iw]
        li = (iw - 1) / 100.0
        field = np.zeros(xs.shape, np.float32)
        srcs = [(ax0 + 22, ay0 + ih / 2.0 + (k - 5.5) * 9.0) for k in range(12)]
        for sx, sy in srcs:
            dist = np.sqrt((xs - (sx - ax0)) ** 2 + (ys - (sy - ay0)) ** 2)
            field += np.cos(2 * np.pi * dist / 34.0 - 2 * np.pi * 0.42 * t)
        field /= len(srcs)
        amp = np.clip((field + 1.0) * 0.5, 0, 1) ** 1.1
        col = st["beam_rgb"]
        band = np.clip(1.0 - ((ys - ih / 2.0) / (ih / 2.0)) ** 2, 0, 1)
        rgb = (amp * band)[..., None] * col[None, None, :] * 0.95
        sub = Image.fromarray(np.clip(rgb * 255 * g, 0, 255).astype(np.uint8), "RGB").convert("RGBA")
        img.paste(sub, (ax0, ay0), sub)
        d.rectangle([ax0 - 1, ay0 - 1, ax0 + iw, ay0 + ih], outline=(170, 190, 215, int(200 * g)), width=2)
        self.draw_mixed(d, (24, 12), "叠加区放大：子波在同一点相遇", 26, C_CN + (int(240 * g),))
        self.draw_mixed(d, (24, 42), "magnified superposition zone (schematic)", 20, C_EN + (int(205 * g),))
        for k in range(12):
            sx = ax0 + 22
            sy = ay0 + ih / 2.0 + (k - 5.5) * 9.0
            d.ellipse([sx - 4, sy - 4, sx + 4, sy + 4], fill=(255, 246, 214, int(220 * g)))
        self.draw_mixed(d, (664, 16), "同相 → 叠加变亮", 24, (255, 236, 190, int(240 * g)))
        self.draw_mixed(d, (664, 50), "in phase: crests add", 20, C_EN + (int(200 * g),))
        self.draw_mixed(d, (664, 84), "反相 → 彼此抵消", 24, (150, 180, 225, int(230 * g)))
        self.draw_mixed(d, (664, 118), "out of phase: they cancel", 20, C_EN + (int(200 * g),))
        self.draw_mixed(d, (664, 152), "示意 schematic", 24, (255, 180, 140, int(235 * g)))
        self.paste_pil(gfx, img, pos)
        self.track_text([(x0, x1)], (y0, y1))

    # ---------------------------------------------------------- overlays ----
    def draw_overlays(self, gfx, gd, st):
        t = st["t"]
        ev = self.ev
        # hook caption
        if ev["hook_show"] - 0.3 <= t <= ev["hook_hide"]:
            g = env(t, ev["hook_show"] - 0.3, ev["hook_hide"], 0.4, 0.5)
            self.text_pair(gfx, "影子中心，为什么有光？",
                           "Why is there light at the centre of the shadow?",
                           (960, 176), 68, 36, g)
        # title
        if ev["title_show"] - 0.3 <= t <= ev["title_hide"]:
            g = env(t, ev["title_show"] - 0.3, ev["title_hide"], 0.5, 0.7)
            self.text_pair(gfx, "泊松亮斑", "Poisson spot / Arago spot",
                           (960, 186), 78, 38, g)
        # final title
        if ev["final_title"] - 0.4 <= t:
            g = env(t, ev["final_title"] - 0.4, 181.0, 0.7, 1.2)
            self.text_pair(gfx, "泊松亮斑", "Poisson spot",
                           (960, 178), 78, 38, g)
        # choice question card
        if ev["choice_show"] - 0.3 <= t <= ev["choice_hide"]:
            g = env(t, ev["choice_show"] - 0.3, ev["choice_hide"], 0.45, 0.5)
            self.choice_card(gfx, st, g)
        # question line (beat 2 close)
        if ev["question_show"] - 0.3 <= t <= ev["question_hide"]:
            g = env(t, ev["question_show"] - 0.3, ev["question_hide"], 0.4, 0.6)
            self.text_pair(gfx, "最该暗的地方，为什么最亮？",
                           "Why is the darkest place the brightest?",
                           (960, 196), 62, 32, g)
        # profile overlay drawn on the screen itself
        if ev["profile_show"] - 0.4 <= t <= ev["profile_hide"]:
            g = env(t, ev["profile_show"] - 0.4, ev["profile_hide"], 0.5, 0.6)
            self.draw_profile(gfx, gd, st, g)
        # magnified superposition zone
        self.superposition_card(gfx, gd, st)
        # terms on first appearance
        if ev["interference"] <= t <= ev["interference"] + 6.0:
            g = env(t, ev["interference"], ev["interference"] + 6.0, 0.5, 0.8)
            self.chip(gfx, "叠加 superposition", "", (1500, 950), anchor="rb",
                      accent=C_ACC, alpha=0.85 * g)
            self.chip(gfx, "示意 schematic", "", (1500, 892), anchor="rb",
                      accent=(255, 180, 140), alpha=0.85 * g)
        if ev["huygens_points"] <= t <= ev["huygens_points"] + 5.5:
            g = env(t, ev["huygens_points"], ev["huygens_points"] + 5.5, 0.5, 0.8)
            self.chip(gfx, "子波 wavelet", "", (1500, 830), anchor="rb",
                      accent=C_ACC, alpha=0.85 * g)
        if ev["huygens_points"] <= t <= ev["huygens_points"] + 6.5:
            gg = env(t, ev["huygens_points"], ev["huygens_points"] + 6.5, 0.5, 0.9)
            self.chip(gfx, "惠更斯原理 Huygens' principle", "", (1480, 950), anchor="rb",
                      accent=C_ACC, alpha=0.85 * gg)
        if ev["m_fresnel"] - 0.2 <= t <= ev["m_fresnel"] + 7.0:
            gg = env(t, ev["m_fresnel"] - 0.2, ev["m_fresnel"] + 7.0, 0.5, 0.9)
            self.chip(gfx, "衍射 diffraction", "", (1480, 882), anchor="rb",
                      accent=C_ACC, alpha=0.85 * gg)
        if ev["equal_path_chip"] <= t <= ev["equal_path_chip"] + 5.0:
            g = env(t, ev["equal_path_chip"], ev["equal_path_chip"] + 5.0, 0.5, 0.8)
            self.chip(gfx, "等光程 equal optical path", "", (620, 950), anchor="rb",
                      accent=C_ACC, alpha=0.85 * g)
        if ev["deform"] <= t <= ev["deform"] + 6.5:
            g = env(t, ev["deform"], ev["deform"] + 6.5, 0.5, 1.0)
            self.chip(gfx, "不等光程 → 相位错开", "unequal paths: phases spread",
                      (620, 830), anchor="rb", accent=(255, 180, 140), alpha=0.85 * g)
            self.chip(gfx, "示意 schematic", "", (620, 892), anchor="rb",
                      accent=(255, 180, 140), alpha=0.85 * g)

    def text_pair(self, gfx, cn, en, xy, sz_cn, sz_en, g):
        if g <= 0.02:
            return
        img, pos = self.new_rgba((200, xy[1] - 90, 1720, xy[1] + 90))
        if img is None:
            return
        d = ImageDraw.Draw(img)
        cx = xy[0] - pos[0]
        cy = xy[1] - pos[1]
        boxes, ybox = self.text_lines(d, [
            dict(text=cn, size=sz_cn, cn=True, color=C_CN, alpha=g),
            dict(text=en, size=sz_en, cn=False, color=C_EN, alpha=g)], cx, cy)
        self.paste_pil(gfx, img, pos)
        self.track_text([(b[0] + pos[0], b[1] + pos[0]) for b in boxes],
                        (ybox[0] + pos[1], ybox[1] + pos[1]))

    def choice_card(self, gfx, st, g):
        img, pos = self.new_rgba((110, 640, 830, 930))
        if img is None:
            return
        d = ImageDraw.Draw(img)
        d.rounded_rectangle([0, 0, 720, 290], radius=20, fill=(10, 14, 22, int(215 * g)),
                            outline=(150, 170, 200, int(120 * g)), width=2)
        self.draw_mixed(d, (28, 22), "如果只按直线传播，中心会怎样？", 40, C_CN + (int(245 * g),))
        self.draw_mixed(d, (28, 76), "If light only went straight, what about the centre?", 24, C_EN + (int(225 * g),))
        opts = [("A  最暗", "darkest"), ("B  最亮", "brightest")]
        for i, (cnl, enl) in enumerate(opts):
            y = 132 + i * 76
            d.rounded_rectangle([28, y, 300, y + 62], radius=12,
                                fill=(20, 26, 38, int(200 * g)),
                                outline=(150, 170, 200, int(150 * g)), width=2)
            self.draw_mixed(d, (46, y + 12), cnl, 32, C_CN + (int(245 * g),))
            self.draw_mixed(d, (46 + 150, y + 18), enl, 22, C_EN + (int(210 * g),))
        self.paste_pil(gfx, img, pos)
        self.track_text([(110, 110 + 720)], (640, 930))

    def draw_profile(self, gfx, gd, st, g):
        cam = st["cam"]
        x0, y0, x1, y1 = self.panel_rect_img(cam)
        ppm = self.px_per_mm(cam)
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        rmax = 6.5
        pw = ppm * 2 * rmax
        ph = min(pw * 0.42, y1 - y0 - 40)
        px0 = cx - pw / 2.0
        py0 = cy + 0.30 * (y1 - y0) / 2.0
        img, pos = self.new_rgba((px0 - 20, py0 - 16, px0 + pw + 20, py0 + ph + 70))
        if img is None:
            return
        d = ImageDraw.Draw(img)
        ox, oy = px0 - pos[0], py0 - pos[1]
        d.rounded_rectangle([ox - 12, oy - 12, ox + pw + 12, oy + ph + 46], radius=16,
                            fill=(6, 9, 15, int(200 * g)),
                            outline=(140, 160, 190, int(120 * g)), width=2)
        # axes
        d.line([ox, oy + ph, ox + pw, oy + ph], fill=(150, 165, 185, int(200 * g)), width=2)
        d.line([ox, oy, ox, oy + ph], fill=(150, 165, 185, int(200 * g)), width=2)
        # geometric expectation (schematic, dashed)
        for k in range(0, 120, 2):
            rr = -rmax + 2 * rmax * k / 120.0
            rr2 = -rmax + 2 * rmax * (k + 1) / 120.0
            yy = 0.06 if abs(rr) < st["a_mm"] else 0.98
            yy2 = 0.06 if abs(rr2) < st["a_mm"] else 0.98
            if abs(yy - yy2) < 1e-6:
                d.line([ox + pw * k / 120.0, oy + ph * (1 - yy * 0.92),
                        ox + pw * (k + 1) / 120.0, oy + ph * (1 - yy2 * 0.92)],
                       fill=(120, 150, 200, int(150 * g)), width=2)
            else:
                d.line([ox + pw * k / 120.0, oy + ph * (1 - yy * 0.92),
                        ox + pw * k / 120.0, oy + ph * (1 - yy2 * 0.92)],
                       fill=(120, 150, 200, int(150 * g)), width=2)
        # computed profile
        n = 420
        L = self.lut(st["lam_nm"], st["a_mm"], self.phys["z_m"])
        pts = []
        for k in range(n + 1):
            rr = -rmax + 2 * rmax * k / n
            I = float(self.pat.intensity(st["lam_nm"], st["a_mm"], self.phys["z_m"], abs(rr)))
            v = clip01(I) ** 0.62
            pts.append((ox + pw * k / n, oy + ph * (1 - v * 0.92)))
        sweep_p = clip01((st["t"] - self.ev["sweep_show"]) / 3.0) if st["t"] >= self.ev["sweep_show"] else 0.0
        upto = int(sweep_p * n) if sweep_p < 1.0 else n
        for k in range(upto):
            d.line([pts[k], pts[k + 1]], fill=(255, 236, 190, int(235 * g)), width=3)
        if sweep_p < 1.0:
            x = pts[upto][0]
            d.line([x, oy - 6, x, oy + ph + 6], fill=(255, 120, 110, int(200 * g)), width=2)
        self.draw_mixed(d, (ox + 8, oy + 6), "亮度剖面 brightness profile", 26, C_CN + (int(235 * g),))
        self.draw_mixed(d, (ox + 8, oy + 38), "computed from the Fresnel diffraction integral", 20, C_EN + (int(210 * g),))
        self.draw_mixed(d, (ox + 8, oy + ph + 8), "几何预期（示意）geometry: dashed", 24, (150, 180, 225, int(220 * g)))
        self.paste_pil(gfx, img, pos)
        self.track_text([(pos[0] + ox - 12, pos[0] + ox + pw + 12)],
                        (pos[1] + oy - 12, pos[1] + oy + ph + 46))

    # --------------------------------------------------------- subtitles ----
    def draw_subtitles(self, gfx, gd, st):
        t = st["t"]
        cur = None
        for ln in self.lines:
            if ln["start"] - 0.05 <= t <= ln["end"] + 0.45:
                cur = ln
                break
        if cur is None:
            return
        g = min(clip01((t - cur["start"] + 0.05) / 0.3), clip01((cur["end"] + 0.45 - t) / 0.35))
        img, pos = self.new_rgba((260, 918, 1660, 1032))
        if img is None:
            return
        d = ImageDraw.Draw(img)
        boxes, ybox = self.text_lines(d, [
            dict(text=cur["cn"], size=48, cn=True, color=C_CN, alpha=g),
            dict(text=cur["en"], size=34, cn=False, color=C_EN, alpha=g)], 700, 57)
        self.paste_pil(gfx, img, pos)
        self.track_text([(b[0] + pos[0], b[1] + pos[0]) for b in boxes],
                        (pos[1], pos[1] + 114))

    def draw_code_label(self, gfx, gd, st):
        g = 0.62
        img, pos = self.new_rgba((110, 42, 1010, 98))
        if img is None:
            return
        d = ImageDraw.Draw(img)
        self.draw_mixed(d, (6, 6), "代码绘制的原理动画 · code-rendered principle animation", 24, C_DIM + (int(255 * g),))
        self.paste_pil(gfx, img, pos)
        # the corner credit is intentionally kept out of the "meaning-bearing
        # text" set: it is a low-interference corner mark (1920x1080 canvas)
        self.credit_extents.append((110.0, 42.0, 1010.0, 98.0))


if __name__ == "__main__":
    import sys
    sc = Scene()
    t = float(sys.argv[1]) if len(sys.argv) > 1 else 16.0
    out = sys.argv[2] if len(sys.argv) > 2 else "still.png"
    import time
    t0 = time.time()
    arr = sc.render(t)
    Image.fromarray(arr).save(out)
    print(f"t={t} -> {out} in {time.time()-t0:.2f}s")
    print("text extents x:", min(e[0] for e in sc.text_extents), max(e[2] for e in sc.text_extents))
    print("text extents y:", min(e[1] for e in sc.text_extents), max(e[3] for e in sc.text_extents))