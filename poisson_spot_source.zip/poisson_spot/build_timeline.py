# -*- coding: utf-8 -*-
"""Synthesise the narration, measure it, lay out the timeline, write timeline.json."""
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import script  # noqa: E402

SKILL = "/home/work/dumate/ba0daecb6b4e41528a2ec116ad38df3a/workspace/skills/official/baidu-text-to-speech/scripts"
VO_RAW = os.path.join(HERE, "build", "vo_raw")
VO = os.path.join(HERE, "build", "vo")
TIMBRE = "4194"     # 度嫣然
SPEED = 4

TRIM = ("silenceremove=start_periods=1:start_silence=0.05:start_threshold=-45dB:detection=peak,"
        "areverse,"
        "silenceremove=start_periods=1:start_silence=0.12:start_threshold=-45dB:detection=peak,"
        "areverse")


def sh(cmd, **kw):
    return subprocess.run(cmd, shell=isinstance(cmd, str), capture_output=True, text=True, **kw)


def tts(text, out_raw):
    tf = out_raw + ".txt"
    with open(tf, "w", encoding="utf-8") as fh:
        fh.write(text)
    r = sh(["python3", "tts.py", "--text_file", tf, "--timbre", TIMBRE,
            "--speed", str(SPEED), "--encoding", "wav", "--output", out_raw], cwd=SKILL)
    if not os.path.exists(out_raw) or os.path.getsize(out_raw) < 2000:
        print("TTS FAILED for", text[:16], r.stdout[-400:], r.stderr[-400:])
        return False
    return True


def probe_dur(path):
    r = sh(["ffprobe", "-v", "error", "-show_entries", "format=duration",
            "-of", "default=nw=1:nk=1", path])
    return float(r.stdout.strip())


def main():
    os.makedirs(VO_RAW, exist_ok=True)
    os.makedirs(VO, exist_ok=True)
    durations, fails = {}, []
    for ln in script.LINES:
        raw = os.path.join(VO_RAW, ln["id"] + ".wav")
        dst = os.path.join(VO, ln["id"] + ".wav")
        if not os.path.exists(dst) or os.path.getsize(dst) < 2000:
            if not tts(ln["cn"], raw):
                fails.append(ln["id"])
                continue
            r = sh(["ffmpeg", "-y", "-v", "error", "-i", raw, "-af", TRIM,
                    "-ar", "48000", "-ac", "2", "-c:a", "pcm_s16le", dst])
            if r.returncode != 0 or not os.path.exists(dst):
                print("TRIM FAILED", ln["id"], r.stderr[-300:])
                fails.append(ln["id"])
                continue
        durations[ln["id"]] = probe_dur(dst)
    if fails:
        print("FAILED LINES:", fails)

    total_cn = sum(len(l["cn"]) for l in script.LINES)
    speech = sum(durations.values())
    print(f"lines={len(script.LINES)} cn_chars={total_cn} speech={speech:.1f}s "
          f"rate={total_cn/speech*60:.0f} chars/min")

    # ---- layout: place clips inside their beat window ----------------------
    lines, cursors = [], {}
    for seg, beat in sorted(script.BEATS.items()):
        cursor = beat["t0"]
        seg_lines = [l for l in script.LINES if l["seg"] == seg]
        # compress the gaps proportionally if the block would overflow
        for i, ln in enumerate(seg_lines):
            gap = 0.0 if i == 0 else beat["gap"]
            dur = durations[ln["id"]]
            lines.append(dict(id=ln["id"], seg=seg, cn=ln["cn"], en=ln["en"],
                              start=round(cursor + gap, 3), dur=round(dur, 3),
                              end=round(cursor + gap + dur, 3),
                              wav=os.path.join(VO, ln["id"] + ".wav")))
            cursor = cursor + gap + dur
        cursors[seg] = cursor
        if cursor > beat["lim"]:
            print(f"  !! beat {seg} overflows by {cursor-beat['lim']:.2f}s "
                  f"(ends {cursor:.2f}, limit {beat['lim']})")
        else:
            print(f"  beat {seg}: {beat['t0']:.2f} -> {cursor:.2f} "
                  f"(limit {beat['lim']}, slack {beat['lim']-cursor:.2f}s)")

    idx = {l["id"]: l for l in lines}
    events = {}
    for name, ref, rel, off in script.CUES:
        if ref is None:
            t = off
        elif rel == "start":
            t = idx[ref]["start"] + off
        elif rel == "end":
            t = idx[ref]["end"] + off
        else:
            raise ValueError(rel)
        events[name] = round(t, 3)

    tl = dict(fps=script.FPS, duration=script.DURATION, width=script.WIDTH,
              height=script.HEIGHT, lines=lines, events=events,
              camera=script.CAMERA, phys=script.PHYS,
              beat_end={str(k): round(v, 3) for k, v in cursors.items()})
    with open(os.path.join(HERE, "timeline.json"), "w", encoding="utf-8") as fh:
        json.dump(tl, fh, ensure_ascii=False, indent=1)
    print("timeline.json written")
    print("events:", json.dumps(events, ensure_ascii=False))


if __name__ == "__main__":
    main()